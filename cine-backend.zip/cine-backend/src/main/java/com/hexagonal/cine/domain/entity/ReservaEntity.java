package com.hexagonal.cine.domain.entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "reserva")
@Data
@EqualsAndHashCode(callSuper = false)
public class ReservaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdReserva")
    private int idReserva;
    @Column(nullable = false)
    private LocalDateTime fechaReserva;
    @ManyToOne
    @JoinColumn(name = "IdCliente", nullable = false, foreignKey = @ForeignKey(name = "FK_RESERVA_CLIENTE"))
    private ClienteEntity cliente;
    @ManyToOne
    @JoinColumn(name = "IdAsiento", nullable = false, foreignKey = @ForeignKey(name = "FK_RESERVA_ASIENTO"))
    private AsientoEntity asiento;
    @ManyToOne
    @JoinColumn(name = "IdCartelera", nullable = false, foreignKey = @ForeignKey(name = "FK_RESERVA_CARTELERA"))
    private CarteleraEntity cartelera;
    @Column(name = "Estado", nullable = false)
    private char estado;
}
