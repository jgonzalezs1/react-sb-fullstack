package com.hexagonal.cine.domain.entity;

import com.hexagonal.cine.domain.enums.GeneroPeliculaEnum;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "pelicula")
@Data
@EqualsAndHashCode(callSuper = false)
public class PeliculaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdPelicula")
    private int idPelicula;
    @Column(name = "nombrePelicula", length = 100, nullable = false)
    private String nombrePelicula;
    @Enumerated(value = EnumType.STRING)
    @Column(name = "generoPelicula", length = 30, nullable = false)
    private GeneroPeliculaEnum generoPelicula;
    @Column(name = "EdadPermitida", nullable = false)
    private int edadPermitida;
    @Column(name = "MinutosDuracion", nullable = false)
    private int minutosDuracion;
    @Column(name = "Estado", nullable = false)
    private char estado;
}
