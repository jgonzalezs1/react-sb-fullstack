package com.hexagonal.cine.repository;

import com.hexagonal.cine.domain.entity.SalaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SalaRepository extends JpaRepository<SalaEntity, Integer> {

}
