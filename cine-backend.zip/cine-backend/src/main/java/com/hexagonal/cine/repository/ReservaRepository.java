package com.hexagonal.cine.repository;

import com.hexagonal.cine.domain.entity.AsientoEntity;
import com.hexagonal.cine.domain.entity.ReservaEntity;
import com.hexagonal.cine.domain.enums.GeneroPeliculaEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ReservaRepository extends JpaRepository<ReservaEntity, Integer> {
    @Query(value = """
            SELECT boo.* FROM reserva boo
                        INNER JOIN cartelera bil ON bil.id_cartelera = boo.id_cartelera
                        INNER JOIN pelicula mov ON mov.id_pelicula = bil.id_pelicula
                        WHERE mov.genero_pelicula = :genero
                        AND bil.fecha_publicacion BETWEEN :fechaInicio AND :fechaFin
            """,
            nativeQuery = true)
    List<ReservaEntity> findAllByGeneroFecha(GeneroPeliculaEnum genero, LocalDateTime fechaInicio, LocalDateTime fechaFin);

    //List<ReservaEntity> findAllAsiento(AsientoEntity asiento);

    @Modifying
    @Query(value = "UPDATE reserva SET estado = :estado WHERE id_reserva = :idReserva", nativeQuery = true)
    void actualizarEstadoAsientoId(@Param(value = "estado") char estado, @Param(value = "idReserva") int idAsiento);
}
