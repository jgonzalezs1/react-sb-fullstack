package com.hexagonal.cine.service.impl;

import com.hexagonal.cine.domain.dto.*;
import com.hexagonal.cine.domain.dto.CarteleraDto;
import com.hexagonal.cine.domain.entity.CarteleraEntity;
import com.hexagonal.cine.domain.interfaces.AsientosOcupadosTotales;
import com.hexagonal.cine.repository.*;
import com.hexagonal.cine.service.CarteleraService;
import com.hexagonal.cine.service.mapper.CarteleraMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
@RequiredArgsConstructor
public class CarteleraServiceImpl implements CarteleraService {
    private final CarteleraRepository carteleraRepository;
    private final PeliculaRepository peliculaRepository;
    private final SalaRepository salaRepository;

    @Override
    public List<CarteleraDto> listAll() {
        return carteleraRepository.findAll().stream().map(CarteleraMapper::toCarteleraDto).toList();
    }

    @Override
    public CarteleraDto findById(Integer id) {
        return CarteleraMapper.toCarteleraDto(carteleraRepository.findById(id).orElseThrow(() -> new NoSuchElementException("La cartelera no encuentra el id " + id)));
    }

    @Override
    public CarteleraDto create(CarteleraDto carteleraDto) {
        CarteleraEntity cartelera = CarteleraMapper.toCartelera(carteleraDto);
        cartelera.setPelicula(peliculaRepository.getReferenceById(carteleraDto.getIdPelicula()));
        cartelera.setSala(salaRepository.getReferenceById(carteleraDto.getIdSala()));
        return CarteleraMapper.toCarteleraDto(carteleraRepository.save(cartelera));
    }

    @Override
    public CarteleraDto update(CarteleraDto carteleraDto) {
        Optional<CarteleraEntity> optional = carteleraRepository.findById(carteleraDto.getIdCartelera());
        if (optional.isPresent()) {
            var entity = optional.get();
            entity.setFechaPublicacion(carteleraDto.getFechaPublicacion());
            entity.setTiempoInicio(carteleraDto.getTiempoInicio());
            entity.setTiempoFin(carteleraDto.getTiempoFin());
            entity.setPelicula(peliculaRepository.getReferenceById(carteleraDto.getIdPelicula()));
            entity.setSala(salaRepository.getReferenceById(carteleraDto.getIdSala()));
            entity.setEstado(carteleraDto.getEstado());
            return CarteleraMapper.toCarteleraDto(carteleraRepository.save(entity));
        } else {
            throw new NoSuchElementException("La cartelera no encuentra el id " + carteleraDto.getIdCartelera());
        }
    }

    @Override
    public void delete(Integer id) {
        if (carteleraRepository.existsById(id)) {
            carteleraRepository.deleteById(id);
        } else {
            throw new NoSuchElementException("La cartelera no encuentra el id " + id);
        }
    }

    @Override
    public AsientosOcupadosDisponiblesResponseDto listAsientosOcupadosDisponiblesSalaFecha(AsientosOcupadosDisponiblesRequestDto filter) {
        AsientosOcupadosTotales result = carteleraRepository.findAllEstadoSalaId(filter.getIdSala(), filter.getFechaCartelera());
        int asientosOcupados = result.getAsientosOcupados()!= null ? result.getAsientosOcupados(): 0;
        int cantidadAsientos = result.getTotal() - asientosOcupados;
        return new AsientosOcupadosDisponiblesResponseDto(cantidadAsientos, asientosOcupados, filter.getFechaCartelera());
    }

    @Override
    public void cancelCartelera(CarteleraDto cartelera) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
