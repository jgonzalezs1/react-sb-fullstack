package com.hexagonal.cine.service;

import com.hexagonal.cine.domain.dto.*;
import com.hexagonal.cine.domain.enums.GeneroPeliculaEnum;
import java.time.LocalDateTime;
import java.util.List;

public interface ReservaService extends CrudGenericoService<ReservaDto, Integer> {
    List<ReservaDto> findByGeneroPeliculaFecha(GeneroPeliculaFechaRequestDto generoPeliculaFecha);
    ReservaDto cancelByAsientoInhabilitado(AsientoDto asientoInhabilitado);
    ReservaDto cancelByCarteleraCancelada(CarteleraDto carteleraCancelada);
    List<ReservaDto> findByGeneroFecha(GeneroPeliculaEnum genero, LocalDateTime fechaInicio, LocalDateTime fechaFin);
}
