package com.hexagonal.cine.domain.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
public class AsientoDto {
    private int idAsiento;
    @NotNull(message = "El número del asiento no puede ser nulo")
    @Min(value = 1, message = "El número del asiento debe de tener el valor mínimo 1")
    private int numeroAsiento;
    @NotNull(message = "El número de la fila no puede ser nulo")
    @Min(value = 1, message = "El número de la fila debe de tener el valor mínimo 1")
    private int numeroFila;
    @NotNull(message = "La sala no puede ser nula")
    private int idSala;
    private String nombreSala;
    @NotNull(message = "El estado no puede ser nulo")
    private char estado;
}
