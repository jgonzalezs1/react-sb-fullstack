package com.hexagonal.cine.domain.dto;

import com.hexagonal.cine.domain.enums.GeneroPeliculaEnum;
import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
public class PeliculaDto {
    private int idPelicula;
    @NotEmpty(message = "El nombre de la película no puede ser nulo o vacio")
    @Size(max = 100, min = 1, message = "El nombre de la película debe ser entre mínimo 1 y máximo 100 caracteres")
    private String nombrePelicula;
    @NotNull(message = "El género de la película no puede ser nulo")
    private GeneroPeliculaEnum generoPelicula;
    @NotNull(message = "La edad permitida no puede ser nula")
    @Min(value = 1, message = "La edad permitida debe ser entre mínima 1")
    private int edadPermitida;
    @NotNull(message = "Los minutos de duración no pueden ser nulos")
    @Min(value = 1, message = "Los minutos de duración deben de ser entre mínimo 1")
    private int minutosDuracion;
    @NotNull(message = "El estado no puede ser nulo")
    private char estado;
}
