package com.hexagonal.cine.domain.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import java.time.LocalDateTime;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
public class ReservaDto {
    private int idReserva;
    @NotNull(message = "La fecha de reserva no puede ser nula")
    @DateTimeFormat(iso = ISO.DATE_TIME)
    private LocalDateTime fechaReserva;
    @NotNull(message = "El cliente no puede ser nulo")
    private int idCliente;
    private String datosCliente;
    @NotNull(message = "La cartelera no puede ser nula")
    private int idCartelera;
    private String datosCartelera;
    @NotNull(message = "El asiento no puede ser nulo")
    private int idAsiento;
    private String datosUbicacion;
    @NotNull(message = "El estado no puede ser nulo")
    private char estado;
}
