package com.hexagonal.cine.service.mapper;

import com.hexagonal.cine.domain.dto.PeliculaDto;
import com.hexagonal.cine.domain.entity.PeliculaEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public class PeliculaMapper {
    public static PeliculaEntity toPelicula(PeliculaDto peliculaDto){
        return new PeliculaEntity(
                peliculaDto.getIdPelicula(),
                peliculaDto.getNombrePelicula(),
                peliculaDto.getGeneroPelicula(),
                peliculaDto.getEdadPermitida(),
                peliculaDto.getMinutosDuracion(),
                peliculaDto.getEstado()
        );
    }
    public static PeliculaDto toPeliculaDto(PeliculaEntity pelicula){
        return new PeliculaDto(
                pelicula.getIdPelicula(),
                pelicula.getNombrePelicula(),
                pelicula.getGeneroPelicula(),
                pelicula.getEdadPermitida(),
                pelicula.getMinutosDuracion(),
                pelicula.getEstado()
        );
    }
}
