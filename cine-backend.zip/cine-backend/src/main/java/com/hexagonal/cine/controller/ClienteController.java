package com.hexagonal.cine.controller;

import com.hexagonal.cine.domain.dto.ClienteDto;
import com.hexagonal.cine.service.ClienteService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.net.URI;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cine/api/v1/clientes")
@RequiredArgsConstructor
public class ClienteController {
    private final ClienteService clienteService;

    @GetMapping
    public ResponseEntity<List<ClienteDto>> list() {
        return ResponseEntity.ok(clienteService.listAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClienteDto> findById(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(clienteService.findById(id));
    }

    @PostMapping
    public ResponseEntity<ClienteDto> create(@RequestBody @Valid ClienteDto clienteDto) {
        ClienteDto createdClient = clienteService.create(clienteDto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(createdClient.getIdCliente()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping
    public ResponseEntity<ClienteDto> update(@RequestBody @Valid ClienteDto clienteDto) {
        return ResponseEntity.ok(clienteService.update(clienteDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ClienteDto> delete(@PathVariable("id") Integer id) {
        clienteService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
