package com.hexagonal.cine.configuration;

import com.hexagonal.cine.domain.dto.base.ErrorDTO;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.util.NoSuchElementException;

@Slf4j
@RestControllerAdvice(annotations = RestController.class)
public class ConfiguracionException {

    @ExceptionHandler(NoSuchElementException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorDTO notFoundException(Exception e, HttpServletRequest req) {
        return new ErrorDTO(HttpStatus.NOT_FOUND, e.getLocalizedMessage(), req.getRequestURI());
    }

    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorDTO bindException(BindException e, HttpServletRequest req) {
        return new ErrorDTO(HttpStatus.BAD_REQUEST, e.getLocalizedMessage(), req.getRequestURI());
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorDTO exception(Exception e, HttpServletRequest req) {
        return new ErrorDTO(HttpStatus.INTERNAL_SERVER_ERROR, e.getLocalizedMessage(), req.getRequestURI());
    }
}
