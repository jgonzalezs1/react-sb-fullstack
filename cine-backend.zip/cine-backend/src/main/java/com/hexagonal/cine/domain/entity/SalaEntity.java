package com.hexagonal.cine.domain.entity;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "sala")
@Data
@EqualsAndHashCode(callSuper = false)
public class SalaEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdSala")
    private int idSala;
    @Column(length = 50, nullable = false)
    private String nombreSala;
    @Column(nullable = false)
    private int numeroSala;
    @Column(name = "Estado", nullable = false)
    private char estado;
}