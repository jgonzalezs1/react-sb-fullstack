package com.hexagonal.cine.service.mapper;

import com.hexagonal.cine.domain.dto.ReservaDto;
import com.hexagonal.cine.domain.entity.ReservaEntity;
import org.mapstruct.Mapper;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.BeanUtils;

@Mapper(componentModel = "spring", uses = {SalaMapper.class, AsientoMapper.class, CarteleraMapper.class})
public class ReservaMapper {

    private static final ModelMapper modelMapper = new ModelMapper();

    public static ReservaEntity toReserva(ReservaDto reservaDto) {
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        ReservaEntity reserva = modelMapper.map(reservaDto, ReservaEntity.class);
        BeanUtils.copyProperties(reservaDto, reserva);
        return reserva;
    }

    public static ReservaDto toReservaDto(ReservaEntity reserva) {
        String datosCliente = reserva.getCliente().getCedula() + " - "
                + reserva.getCliente().getNombre() + " " + reserva.getCliente().getApellido();
        String datosCartelera = reserva.getCartelera().getPelicula().getNombrePelicula() + " - "
                + reserva.getCartelera().getPelicula().getGeneroPelicula()
                + " (" + reserva.getCartelera().getTiempoInicio() + " - " + reserva.getCartelera().getTiempoFin() + ")";
        String datosUbicacion = "FILA: " + reserva.getAsiento().getNumeroFila() + " - ASIENTO: " + reserva.getAsiento().getNumeroAsiento();
        return new ReservaDto(
                reserva.getIdReserva(),
                reserva.getFechaReserva(),
                reserva.getCliente().getIdCliente(),
                datosCliente,
                reserva.getCartelera().getIdCartelera(),
                datosCartelera,
                reserva.getAsiento().getIdAsiento(),
                datosUbicacion,
                reserva.getEstado()
        );
    }
}
