package com.hexagonal.cine.service;

import com.hexagonal.cine.domain.dto.PeliculaDto;

public interface PeliculaService extends CrudGenericoService<PeliculaDto, Integer> {

}
