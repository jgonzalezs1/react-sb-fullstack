package com.hexagonal.cine.service.mapper;

import com.hexagonal.cine.domain.dto.ClienteDto;
import com.hexagonal.cine.domain.entity.ClienteEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public class ClienteMapper {
    public static ClienteEntity toCliente(ClienteDto clienteDto){
        return new ClienteEntity(
                clienteDto.getIdCliente(),
                clienteDto.getCedula(),
                clienteDto.getNombre(),
                clienteDto.getApellido(),
                clienteDto.getEdad(),
                clienteDto.getTelefono(),
                clienteDto.getCorreo(),
                clienteDto.getEstado()
        );
    }
    public static ClienteDto toClienteDto(ClienteEntity cliente){
        return new ClienteDto(
                cliente.getIdCliente(),
                cliente.getCedula(),
                cliente.getNombre(),
                cliente.getApellido(),
                cliente.getEdad(),
                cliente.getTelefono(),
                cliente.getCorreo(),
                cliente.getEstado()
        );
    }
}
