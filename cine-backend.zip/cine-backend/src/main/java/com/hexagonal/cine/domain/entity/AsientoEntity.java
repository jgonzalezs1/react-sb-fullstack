package com.hexagonal.cine.domain.entity;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "asiento")
@Data
@EqualsAndHashCode(callSuper = false)
public class AsientoEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdAsiento")
    private int idAsiento;
    @Column(name = "NumeroAsiento", nullable = false)
    private int numeroAsiento;
    @Column(name = "NumeroFila", nullable = false)
    private int numeroFila;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdSala", nullable = false, foreignKey = @ForeignKey(name = "FK_ASIENTO_SALA"))
    private SalaEntity sala;
    @Column(name = "Estado", nullable = false)
    private char estado;
}
