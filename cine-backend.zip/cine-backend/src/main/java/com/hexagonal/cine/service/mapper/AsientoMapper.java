package com.hexagonal.cine.service.mapper;

import com.hexagonal.cine.domain.dto.*;
import com.hexagonal.cine.domain.entity.AsientoEntity;
import org.mapstruct.Mapper;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.BeanUtils;

@Mapper(componentModel = "spring", uses = SalaMapper.class)
public class AsientoMapper {   
    
    private static final ModelMapper modelMapper = new ModelMapper();
    
    public static AsientoEntity toAsiento(AsientoDto asientoDto){
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        AsientoEntity asiento = modelMapper.map(asientoDto, AsientoEntity.class);
        BeanUtils.copyProperties(asientoDto, asiento);
        return asiento;
    }
    
    public static AsientoDto toAsientoDto(AsientoEntity asiento) {
        return new AsientoDto(
                asiento.getIdAsiento(),
                asiento.getNumeroAsiento(),
                asiento.getNumeroFila(),
                asiento.getSala().getIdSala(),
                asiento.getSala().getNombreSala(),
                asiento.getEstado()
        );
    }
}