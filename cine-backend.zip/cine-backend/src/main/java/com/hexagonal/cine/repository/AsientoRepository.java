package com.hexagonal.cine.repository;

import com.hexagonal.cine.domain.entity.AsientoEntity;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AsientoRepository extends JpaRepository<AsientoEntity, Integer> {

    @Modifying
    @Query(value = "UPDATE asiento SET estado = :estado WHERE id_asiento = :idAsiento", nativeQuery = true)
    void actualizarEstadoId(@Param(value = "estado") char estado, @Param(value = "idAsiento") int idAsiento);
}
