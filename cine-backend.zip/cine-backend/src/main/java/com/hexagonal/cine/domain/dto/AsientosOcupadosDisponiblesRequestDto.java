package com.hexagonal.cine.domain.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
public class AsientosOcupadosDisponiblesRequestDto {
    @NotNull(message = "La sala no puede ser nula")
    @Min(value = 1)
    private Integer idSala;
    @NotNull(message = "La fecha de cartelera no puede ser nula")
    @DateTimeFormat(iso = ISO.DATE)
    private LocalDate fechaCartelera;
}
