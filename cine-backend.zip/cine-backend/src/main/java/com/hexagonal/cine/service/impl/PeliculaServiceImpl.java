package com.hexagonal.cine.service.impl;

import com.hexagonal.cine.domain.dto.PeliculaDto;
import com.hexagonal.cine.domain.entity.PeliculaEntity;
import com.hexagonal.cine.repository.PeliculaRepository;
import com.hexagonal.cine.service.PeliculaService;
import com.hexagonal.cine.service.mapper.PeliculaMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
@RequiredArgsConstructor
public class PeliculaServiceImpl implements PeliculaService {
    private final PeliculaRepository peliculaRepository;

    @Override
    public List<PeliculaDto> listAll() {
        return peliculaRepository.findAll().stream().map(PeliculaMapper::toPeliculaDto).toList();
    }

    @Override
    public PeliculaDto findById(Integer id) {
        return peliculaRepository.findById(id).map(PeliculaMapper::toPeliculaDto).orElseThrow(() -> new NoSuchElementException("La película no encuentra el id " + id));
    }

    @Override
    public PeliculaDto create(PeliculaDto t) {
        PeliculaEntity pelicula = PeliculaMapper.toPelicula(t);
        return PeliculaMapper.toPeliculaDto(peliculaRepository.save(pelicula));
    }

    @Override
    public PeliculaDto update(PeliculaDto t) {
        Optional<PeliculaEntity> optional = peliculaRepository.findById(t.getIdPelicula());
        if (optional.isPresent()) {
            var entity = optional.get();
            entity.setNombrePelicula(t.getNombrePelicula());
            entity.setGeneroPelicula(t.getGeneroPelicula());
            entity.setEdadPermitida(t.getEdadPermitida());
            entity.setMinutosDuracion(t.getMinutosDuracion());
            entity.setEstado(t.getEstado());
            return PeliculaMapper.toPeliculaDto(peliculaRepository.save(entity));
        } else {
            throw new NoSuchElementException("La película no encuentra el id " + t.getIdPelicula());
        }
    }

    @Override
    public void delete(Integer id) {
        if (peliculaRepository.existsById(id)) {
            peliculaRepository.deleteById(id);
        } else {
            throw new NoSuchElementException("La película no encuentra el id " + id);
        }
    }
}
