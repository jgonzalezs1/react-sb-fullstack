package com.hexagonal.cine.domain.interfaces;

public interface AsientosOcupadosTotales {
    Integer getAsientosOcupados();
    Integer getTotal();
}
