package com.hexagonal.cine.controller;

import com.hexagonal.cine.domain.dto.*;
import com.hexagonal.cine.service.CarteleraService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.net.URI;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cine/api/v1/carteleras")
@RequiredArgsConstructor
public class CarteleraController {
    private final CarteleraService carteleraService;

    @GetMapping
    public ResponseEntity<List<CarteleraDto>> list() {
        return ResponseEntity.ok(carteleraService.listAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CarteleraDto> findById(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(carteleraService.findById(id));
    }

    @GetMapping("/estado")
    public ResponseEntity<AsientosOcupadosDisponiblesResponseDto> listAsientosOcupadosDisponiblesSalaFecha(@Valid AsientosOcupadosDisponiblesRequestDto filter) {
        return ResponseEntity.ok(carteleraService.listAsientosOcupadosDisponiblesSalaFecha(filter));
    }

    @PostMapping
    public ResponseEntity<CarteleraDto> create(@RequestBody @Valid CarteleraDto carteleraDto) {
        CarteleraDto createdCarteleraDto = carteleraService.create(carteleraDto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(createdCarteleraDto.getIdCartelera()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping
    public ResponseEntity<CarteleraDto> update(@RequestBody @Valid CarteleraDto carteleraDto) {
        return ResponseEntity.ok(carteleraService.update(carteleraDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Integer id) {
        carteleraService.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
