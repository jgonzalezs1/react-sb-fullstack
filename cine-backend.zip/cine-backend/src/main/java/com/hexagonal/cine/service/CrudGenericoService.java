package com.hexagonal.cine.service;

import java.util.List;

public interface CrudGenericoService<T, I> {
    List<T> listAll();
    T findById(I i);
    T create(T t);
    T update(T t);
    void delete(I i);
}
