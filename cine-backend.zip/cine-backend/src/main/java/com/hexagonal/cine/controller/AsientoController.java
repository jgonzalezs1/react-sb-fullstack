package com.hexagonal.cine.controller;

import com.hexagonal.cine.domain.dto.AsientoDto;
import com.hexagonal.cine.service.AsientoService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.net.URI;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cine/api/v1/asientos")
@RequiredArgsConstructor
public class AsientoController {
    private final AsientoService asientoService;
  
    @GetMapping
    public ResponseEntity<List<AsientoDto>> list() {
        return ResponseEntity.ok(asientoService.listAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AsientoDto> findById(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(asientoService.findById(id));
    }

    @PostMapping
    public ResponseEntity<AsientoDto> create(@RequestBody @Valid AsientoDto asientoDto) {
        AsientoDto createdCliente = asientoService.create(asientoDto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(createdCliente.getIdAsiento()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping
    public ResponseEntity<AsientoDto> update(@RequestBody @Valid AsientoDto asientoDto) {
        return ResponseEntity.ok(asientoService.update(asientoDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") Integer id) {
        asientoService.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PatchMapping("/inhabilite/{id}")
    public ResponseEntity<Void> inhabilite(@PathVariable("id") Integer id) {
        asientoService.inhabilite(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
