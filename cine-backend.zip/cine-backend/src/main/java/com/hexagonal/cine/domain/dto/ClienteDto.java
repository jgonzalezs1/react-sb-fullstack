package com.hexagonal.cine.domain.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
public class ClienteDto {
    private int idCliente;
    @NotEmpty(message = "La cédula no puede ser nula o vacía")
    @Size(max = 20, min = 8, message = "La cédula debe tener entre mínimo 8 y máximo 20 caracteres")
    private String cedula;
    @NotEmpty(message = "El nombre no puede ser nulo o vacío")
    @Size(max = 30, min = 1, message = "El nombre debe de tener entre mínimo 1 y máximo 30 caracteres")
    private String nombre;
    @NotEmpty(message = "El apellido no puede ser nulo o vacío")
    @Size(max = 30, min = 1, message = "El apellido debe de tener entre mínimo 1 y máximo 30 caracteres")
    private String apellido;
    @NotNull(message = "La edad no puede ser nula")
    @Min(value = 1, message = "La edad debe de tener debe de tener el valor mínimo 1")
    private int edad;
    @Size(max = 20, min = 0, message = "El número de teléfono debe de tener entre mínimo 1 y máximo 20 caracteres")
    private String telefono;
    @Email(message = "Ingrese un correo electrónico válido")
    private String correo;
    @NotNull(message = "El estado no puede ser nulo")
    private char estado;
}
