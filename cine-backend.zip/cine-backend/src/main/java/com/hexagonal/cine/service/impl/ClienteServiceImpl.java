package com.hexagonal.cine.service.impl;

import com.hexagonal.cine.domain.dto.ClienteDto;
import com.hexagonal.cine.domain.entity.ClienteEntity;
import com.hexagonal.cine.repository.ClienteRepository;
import com.hexagonal.cine.service.ClienteService;
import com.hexagonal.cine.service.mapper.ClienteMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ClienteServiceImpl implements ClienteService {
    private final ClienteRepository clienteRepository;

    @Override
    public List<ClienteDto> listAll() {
        return clienteRepository.findAll().stream().map(ClienteMapper::toClienteDto).toList();
    }

    @Override
    public ClienteDto findById(Integer id) {
        return clienteRepository.findById(id).map(ClienteMapper::toClienteDto).orElseThrow(() -> new NoSuchElementException("El cliente no encuentra el id " + id));
    }

    @Override
    public ClienteDto create(ClienteDto t) {
        ClienteEntity customer = ClienteMapper.toCliente(t);
        return ClienteMapper.toClienteDto(clienteRepository.save(customer));
    }

    @Override
    public ClienteDto update(ClienteDto t) {
        Optional<ClienteEntity> optional = clienteRepository.findById(t.getIdCliente());
        if (optional.isPresent()) {
            var entity = optional.get();
            entity.setCedula(t.getCedula());
            entity.setNombre(t.getNombre());
            entity.setApellido(t.getApellido());
            entity.setEdad(t.getEdad());
            entity.setTelefono(t.getTelefono());
            entity.setCorreo(t.getCorreo());
            entity.setEstado(t.getEstado());
            return ClienteMapper.toClienteDto(clienteRepository.save(entity));
        } else {
            throw new NoSuchElementException("El cliente no encuentra el id " + t.getIdCliente());
        }
    }

    @Override
    public void delete(Integer id) {
        if (clienteRepository.existsById(id)) {
            clienteRepository.deleteById(id);
        } else {
            throw new NoSuchElementException("El cliente no encuentra el id " + id);
        }
    }
}
