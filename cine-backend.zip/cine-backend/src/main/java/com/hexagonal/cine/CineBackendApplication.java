package com.hexagonal.cine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CineBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(CineBackendApplication.class, args);
    }

}
