package com.hexagonal.cine.domain.entity;

import java.time.*;
import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cartelera")
@Data
@EqualsAndHashCode(callSuper = false)
public class CarteleraEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdCartelera")
    private int idCartelera;
    @Column(name = "FechaPublicacion", nullable = false)
    private LocalDate fechaPublicacion;
    @Column(name = "TiempoInicio", nullable = false)
    private LocalTime tiempoInicio;
    @Column(name = "TiempoFin", nullable = false)
    private LocalTime tiempoFin;
    @ManyToOne
    @JoinColumn(name = "IdPelicula", nullable = false, foreignKey = @ForeignKey(name = "FK_CARTELERA_PELICULA"))
    private PeliculaEntity pelicula;
    @ManyToOne
    @JoinColumn(name = "IdSala", nullable = false, foreignKey = @ForeignKey(name = "FK_CARTELERA_SALA"))
    private SalaEntity sala;
    @Column(name = "Estado", nullable = false)
    private char estado;
}
