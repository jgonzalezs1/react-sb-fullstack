package com.hexagonal.cine.domain.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
public class SalaDto {
    private int idSala;
    @NotEmpty(message = "El nombre de la sala no puede ser nulo o vacío")
    @Size(max = 50, min = 1, message = "El nombre de la sala debe ser entre mínimo 1 y máximo 50 caracteres")
    private String nombreSala;
    @NotNull(message = "number no puede ser nulo")
    @Min(value = 1, message = "El número de la sala debe de tener el valor mínimo 1")
    private int numeroSala;
    @NotNull(message = "El estado no puede ser nulo")
    private char estado;
}
