package com.hexagonal.cine.service.mapper;

import com.hexagonal.cine.domain.dto.CarteleraDto;
import com.hexagonal.cine.domain.entity.CarteleraEntity;
import org.mapstruct.Mapper;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.BeanUtils;

@Mapper(componentModel = "spring", uses = {PeliculaMapper.class, SalaMapper.class})
public class CarteleraMapper {
    
    private static final ModelMapper modelMapper = new ModelMapper();
    
    public static CarteleraEntity toCartelera(CarteleraDto carteleraDto){
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        CarteleraEntity cartelera = modelMapper.map(carteleraDto, CarteleraEntity.class);
        BeanUtils.copyProperties(carteleraDto, cartelera);
        return cartelera;
    }
    
    public static CarteleraDto toCarteleraDto(CarteleraEntity cartelera){
        return new CarteleraDto(
                cartelera.getIdCartelera(),
                cartelera.getFechaPublicacion(),
                cartelera.getTiempoInicio(),
                cartelera.getTiempoFin(),
                cartelera.getPelicula().getIdPelicula(),
                cartelera.getPelicula().getNombrePelicula(),
                cartelera.getPelicula().getGeneroPelicula().toString(),
                cartelera.getSala().getIdSala(),
                cartelera.getSala().getNombreSala(),
                cartelera.getSala().getNumeroSala(),
                cartelera.getEstado()
        );
    }
}
