package com.hexagonal.cine.service;

import com.hexagonal.cine.domain.dto.ClienteDto;

public interface ClienteService extends CrudGenericoService<ClienteDto, Integer> {

}
