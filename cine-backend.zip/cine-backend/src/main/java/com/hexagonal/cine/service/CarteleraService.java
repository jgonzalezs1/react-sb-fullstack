package com.hexagonal.cine.service;

import com.hexagonal.cine.domain.dto.*;

public interface CarteleraService extends CrudGenericoService<CarteleraDto, Integer> {
    AsientosOcupadosDisponiblesResponseDto listAsientosOcupadosDisponiblesSalaFecha(AsientosOcupadosDisponiblesRequestDto filter);
    void cancelCartelera(CarteleraDto cartelera);
}
