package com.hexagonal.cine.service.impl;

import com.hexagonal.cine.domain.dto.*;
import com.hexagonal.cine.domain.entity.AsientoEntity;
import com.hexagonal.cine.repository.*;
import com.hexagonal.cine.service.AsientoService;
import com.hexagonal.cine.service.mapper.AsientoMapper;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.*;
import org.springframework.beans.BeanUtils;

@Service
@RequiredArgsConstructor
public class AsientoServiceImpl implements AsientoService {

    private final AsientoRepository asientoRepository;
    private final SalaRepository salaRepository;
    private final ReservaRepository reservaRepository;

    @Override
    public List<AsientoDto> listAll() {
        return asientoRepository.findAll().stream().map(AsientoMapper::toAsientoDto).toList();
    }

    @Override
    public AsientoDto findById(Integer id) {
        return AsientoMapper.toAsientoDto(asientoRepository.findById(id).orElseThrow(() -> new NoSuchElementException("El asiento no encuentra el id " + id)));
    }

    @Override
    public AsientoDto create(AsientoDto asientoDto) {
        AsientoEntity asiento = AsientoMapper.toAsiento(asientoDto);
        asiento.setSala(salaRepository.getReferenceById(asientoDto.getIdSala()));
        return AsientoMapper.toAsientoDto(asientoRepository.save(asiento));
    }

    @Override
    public AsientoDto update(AsientoDto asientoDto) {
        Optional<AsientoEntity> optional = asientoRepository.findById(asientoDto.getIdAsiento());
        if (optional.isPresent()) {
            var entity = optional.get();
            BeanUtils.copyProperties(asientoDto, entity);
            entity.setNumeroAsiento(asientoDto.getNumeroAsiento());
            entity.setNumeroFila(asientoDto.getNumeroFila());
            entity.setSala(salaRepository.getReferenceById(asientoDto.getIdSala()));
            entity.setEstado(asientoDto.getEstado());
            return AsientoMapper.toAsientoDto(asientoRepository.save(entity));
        } else {
            throw new NoSuchElementException("El asiento no encuentra el id " + asientoDto.getIdAsiento());
        }
    }

    @Override
    public void delete(Integer id) {
        if (asientoRepository.existsById(id)) {
            asientoRepository.deleteById(id);
        } else {
            throw new NoSuchElementException("El asiento no encuentra el id " + id);
        }
    }

    @Override
    @Transactional
    public void inhabilite(Integer id) {
        asientoRepository.actualizarEstadoId('B', id);
        reservaRepository.actualizarEstadoAsientoId('B', id);
    }
}
