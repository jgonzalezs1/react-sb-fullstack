package com.hexagonal.cine.domain.entity;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cliente")
@Data
@EqualsAndHashCode(callSuper = false)
public class ClienteEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdCliente")
    private int idCliente;
    @Column(name = "Cedula", length = 10, nullable = false, unique = true)
    private String cedula;
    @Column(name = "Nombre", length = 50, nullable = false)
    private String nombre;
    @Column(name = "Apellido", length = 50, nullable = false)
    private String apellido;
    @Column(name = "Edad", nullable = false)
    private int edad;
    @Column(name = "Telefono", length = 10)
    private String telefono;
    @Column(name = "Correo", length = 25)
    private String correo;
    @Column(name = "Estado", nullable = false)
    private char estado;
}
