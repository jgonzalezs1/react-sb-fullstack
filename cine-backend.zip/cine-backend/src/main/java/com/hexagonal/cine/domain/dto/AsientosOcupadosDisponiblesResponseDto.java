package com.hexagonal.cine.domain.dto;

import lombok.*;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AsientosOcupadosDisponiblesResponseDto {
    private Integer asientosDisponibles;
    private Integer asientosOcupados;
    private LocalDate fechaCartelera;
}
