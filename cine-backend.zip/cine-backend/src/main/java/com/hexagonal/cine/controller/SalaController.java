package com.hexagonal.cine.controller;

import com.hexagonal.cine.domain.dto.SalaDto;
import com.hexagonal.cine.service.SalaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.net.URI;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cine/api/v1/salas")
@RequiredArgsConstructor
@Validated
public class SalaController {
    private final SalaService salaService;
    
    @GetMapping
    public ResponseEntity<List<SalaDto>> list() {
        return ResponseEntity.ok(salaService.listAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SalaDto> findById(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(salaService.findById(id));
    }

    @PostMapping
    public ResponseEntity<SalaDto> create(@RequestBody @Valid SalaDto roomDto) {
        SalaDto createdClient = salaService.create(roomDto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(createdClient.getIdSala()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping
    public ResponseEntity<SalaDto> update(@RequestBody @Valid SalaDto roomDto) {
        return ResponseEntity.ok(salaService.update(roomDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<SalaDto> delete(@PathVariable("id") Integer id) {
        salaService.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
