package com.hexagonal.cine.domain.dto;

import com.hexagonal.cine.domain.enums.GeneroPeliculaEnum;
import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import java.time.LocalDateTime;

@Data
@EqualsAndHashCode(callSuper = false)
public class GeneroPeliculaFechaRequestDto {
    @NotNull(message = "El género de la película no puede ser nulo")
    private GeneroPeliculaEnum generoPelicula;
    @NotNull(message = "La fecha de inicio de la función no puede ser nulo")
    @DateTimeFormat(iso = ISO.DATE_TIME)
    private LocalDateTime fechaInicio;
    @NotNull(message = "La fecha de fin de la función no puede ser nulo")
    @DateTimeFormat(iso = ISO.DATE_TIME)
    private LocalDateTime fechaFin;
}
