package com.hexagonal.cine.service;

import com.hexagonal.cine.domain.dto.AsientoDto;

public interface AsientoService extends CrudGenericoService<AsientoDto, Integer> {
    public abstract void inhabilite(Integer id);
}
