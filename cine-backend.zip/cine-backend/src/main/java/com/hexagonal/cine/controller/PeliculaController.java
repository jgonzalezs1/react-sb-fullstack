package com.hexagonal.cine.controller;

import com.hexagonal.cine.domain.dto.PeliculaDto;
import com.hexagonal.cine.service.PeliculaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.net.URI;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cine/api/v1/peliculas")
@RequiredArgsConstructor
public class PeliculaController {
    private final PeliculaService peliculaService;
    
    @GetMapping
    public ResponseEntity<List<PeliculaDto>> list() {
        return ResponseEntity.ok(peliculaService.listAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PeliculaDto> findById(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(peliculaService.findById(id));
    }

    @PostMapping
    public ResponseEntity<PeliculaDto> create(@RequestBody @Valid PeliculaDto movieDto) {
        PeliculaDto createdClient = peliculaService.create(movieDto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(createdClient.getIdPelicula()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping
    public ResponseEntity<PeliculaDto> update(@RequestBody @Valid PeliculaDto movieDto) {
        return ResponseEntity.ok(peliculaService.update(movieDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<PeliculaDto> delete(@PathVariable("id") Integer id) {
        peliculaService.delete(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
