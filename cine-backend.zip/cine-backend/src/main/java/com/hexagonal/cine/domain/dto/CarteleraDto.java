package com.hexagonal.cine.domain.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import java.time.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
public class CarteleraDto {
    private int idCartelera;
    @NotNull(message = "La fecha de publicación de la cartelera no puede ser nula")
    @DateTimeFormat(iso = ISO.DATE)
    private LocalDate fechaPublicacion;
    @NotNull(message = "El tiempo de inicio no puede ser nulo")
    @DateTimeFormat(iso = ISO.TIME)
    private LocalTime tiempoInicio;
    @NotNull(message = "El tiempo de fin no puede ser nulo")
    @DateTimeFormat(iso = ISO.TIME)
    private LocalTime tiempoFin;
    @NotNull(message = "La película no puede ser nula")
    private int idPelicula;
    private String nombrePelicula;
    private String generoPelicula;
    @NotNull(message = "La sala no puede ser nula")
    private int idSala;
    private String nombreSala;
    private int numeroSala;
    @NotNull(message = "El estado no puede ser nulo")
    private char estado;
}
