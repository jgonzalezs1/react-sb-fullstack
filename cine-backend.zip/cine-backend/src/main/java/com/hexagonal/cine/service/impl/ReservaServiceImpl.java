package com.hexagonal.cine.service.impl;

import com.hexagonal.cine.domain.dto.*;
import com.hexagonal.cine.domain.entity.ReservaEntity;
import com.hexagonal.cine.domain.enums.GeneroPeliculaEnum;
import com.hexagonal.cine.repository.*;
import com.hexagonal.cine.service.ReservaService;
import com.hexagonal.cine.service.mapper.ReservaMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.*;

@Service
@RequiredArgsConstructor
public class ReservaServiceImpl implements ReservaService {

    private final ReservaRepository reservaRepository;
    private final ClienteRepository clienteRepository;
    private final AsientoRepository asientoRepository;
    private final CarteleraRepository carteleraRepository;

    @Override
    public List<ReservaDto> listAll() {
        return reservaRepository.findAll().stream().map(ReservaMapper::toReservaDto).toList();
    }

    @Override
    public ReservaDto findById(Integer id) {
        return reservaRepository.findById(id).map(ReservaMapper::toReservaDto)
                .orElseThrow(() -> new NoSuchElementException("La reserva no encuentra el id " + id));
    }

    @Override
    public ReservaDto create(ReservaDto reservaDto) {
        ReservaEntity reserva = ReservaMapper.toReserva(reservaDto);
        reserva.setCliente(clienteRepository.getReferenceById(reservaDto.getIdCliente()));
        reserva.setCartelera(carteleraRepository.getReferenceById(reservaDto.getIdAsiento()));
        reserva.setAsiento(asientoRepository.getReferenceById(reservaDto.getIdAsiento()));
        return ReservaMapper.toReservaDto(reservaRepository.save(reserva));
    }

    @Override
    @Modifying
    @Transactional
    public ReservaDto update(ReservaDto reservaDto) {
        Optional<ReservaEntity> optional = reservaRepository.findById(reservaDto.getIdReserva());
        if (optional.isPresent()) {
            var entity = optional.get();
            entity.setFechaReserva(reservaDto.getFechaReserva());
            entity.setCliente(clienteRepository.getReferenceById(reservaDto.getIdCliente()));
            entity.setCartelera(carteleraRepository.getReferenceById(reservaDto.getIdAsiento()));
            entity.setAsiento(asientoRepository.getReferenceById(reservaDto.getIdAsiento()));
            entity.setEstado(reservaDto.getEstado());
            return ReservaMapper.toReservaDto(reservaRepository.save(entity));
        } else {
            throw new NoSuchElementException("La reserva no encuentra el id " + reservaDto.getIdReserva());
        }
    }

    @Override
    public void delete(Integer id) {
        if (reservaRepository.existsById(id)) {
            reservaRepository.deleteById(id);
        } else {
            throw new NoSuchElementException("La reserva no encuentra el id " + id);
        }
    }

    @Override
    public List<ReservaDto> findByGeneroPeliculaFecha(GeneroPeliculaFechaRequestDto generoPeliculaFecha) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ReservaDto cancelByAsientoInhabilitado(AsientoDto asientoInhabilitado) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public ReservaDto cancelByCarteleraCancelada(CarteleraDto carteleraCancelada) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<ReservaDto> findByGeneroFecha(GeneroPeliculaEnum genero, LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        return reservaRepository.findAllByGeneroFecha(genero, fechaInicio, fechaFin).stream()
                .map(ReservaMapper::toReservaDto).toList();
    }
}
