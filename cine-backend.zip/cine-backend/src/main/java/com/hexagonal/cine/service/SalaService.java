package com.hexagonal.cine.service;

import com.hexagonal.cine.domain.dto.SalaDto;

public interface SalaService extends CrudGenericoService<SalaDto, Integer> {

}
