package com.hexagonal.cine.service.mapper;

import com.hexagonal.cine.domain.dto.SalaDto;
import com.hexagonal.cine.domain.entity.*;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public class SalaMapper {
    public static SalaEntity toSala(SalaDto salaDto){
        return new SalaEntity(
                salaDto.getIdSala(),
                salaDto.getNombreSala(),
                salaDto.getNumeroSala(),
                salaDto.getEstado()
        );
    }
    public static SalaDto toSalaDto(SalaEntity sala){
        return new SalaDto(
                sala.getIdSala(),
                sala.getNombreSala(),
                sala.getNumeroSala(),
                sala.getEstado()
        );
    }
}
