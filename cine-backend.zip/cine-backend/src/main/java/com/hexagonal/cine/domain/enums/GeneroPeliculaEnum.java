package com.hexagonal.cine.domain.enums;

public enum GeneroPeliculaEnum {
    ACCION, 
    AVENTURA, 
    COMEDIA, 
    DRAMA, 
    FANTASIA, 
    TERROR, 
    MUSICALES, 
    MISTERIO, 
    ROMANCE, 
    CIENCIA_FICCION, 
    DEPORTES, 
    SUSPENSO, 
    VIEJO_OESTE
}
