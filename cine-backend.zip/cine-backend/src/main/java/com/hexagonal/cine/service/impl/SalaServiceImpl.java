package com.hexagonal.cine.service.impl;

import com.hexagonal.cine.domain.dto.SalaDto;
import com.hexagonal.cine.domain.entity.SalaEntity;
import com.hexagonal.cine.repository.SalaRepository;
import com.hexagonal.cine.service.SalaService;
import com.hexagonal.cine.service.mapper.SalaMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SalaServiceImpl implements SalaService {
    private final SalaRepository salaRepository;

    @Override
    public List<SalaDto> listAll() {
        return salaRepository.findAll().stream().map(SalaMapper::toSalaDto).toList();
    }

    @Override
    public SalaDto findById(Integer id) {
        return salaRepository.findById(id).map(SalaMapper::toSalaDto).orElseThrow(() -> new NoSuchElementException("La sala no encuentra el id " + id));
    }

    @Override
    public SalaDto create(SalaDto t) {
        SalaEntity sala = SalaMapper.toSala(t);
        return SalaMapper.toSalaDto(salaRepository.save(sala));
    }

    @Override
    public SalaDto update(SalaDto t) {
        Optional<SalaEntity> optional = salaRepository.findById(t.getIdSala());
        if (optional.isPresent()) {
            var entity = optional.get();
            entity.setNombreSala(t.getNombreSala());
            entity.setNumeroSala(t.getNumeroSala());
            entity.setEstado(t.getEstado());
            return SalaMapper.toSalaDto(salaRepository.save(entity));
        } else {
            throw new NoSuchElementException("La sala no encuentra el id " + t.getIdSala());
        }
    }

    @Override
    public void delete(Integer id) {
        if (salaRepository.existsById(id)) {
            salaRepository.deleteById(id);
        } else {
            throw new NoSuchElementException("La sala no encuentra el id " + id);
        }
    }
}
