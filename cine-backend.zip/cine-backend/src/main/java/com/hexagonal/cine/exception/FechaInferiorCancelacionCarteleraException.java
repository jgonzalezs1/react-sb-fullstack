package com.hexagonal.cine.exception;

public class FechaInferiorCancelacionCarteleraException extends RuntimeException {

    public FechaInferiorCancelacionCarteleraException(String message) {
        super(message);
    }
}
