package com.hexagonal.cine.repository;

import com.hexagonal.cine.domain.entity.CarteleraEntity;
import com.hexagonal.cine.domain.interfaces.AsientosOcupadosTotales;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;

@Repository
public interface CarteleraRepository extends JpaRepository<CarteleraEntity, Integer> {
    @Query(value = """
             SELECT COUNT(ALL boo.estado = 1) AS AsientoOcupado,
                         (SELECT COUNT(*) FROM asiento s WHERE s.id_sala = :idSala) AS total
                          FROM asiento sea
                          INNER JOIN reserva boo ON boo.id_asiento = sea.id_asiento
                          INNER JOIN cartelera bil ON bil.id_cartelera = boo.id_cartelera
                          WHERE sea.id_sala = :idSala
                          AND bil.fecha_publicacion = :fechaPublicacion
            """,
            nativeQuery = true)
    AsientosOcupadosTotales findAllEstadoSalaId(int idSala, LocalDate fechaPublicacion);
}
