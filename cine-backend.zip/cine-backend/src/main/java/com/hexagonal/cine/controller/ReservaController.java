package com.hexagonal.cine.controller;

import com.hexagonal.cine.domain.dto.ReservaDto;
import com.hexagonal.cine.domain.enums.GeneroPeliculaEnum;
import com.hexagonal.cine.service.ReservaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import java.net.URI;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/cine/api/v1/reservas")
@RequiredArgsConstructor
public class ReservaController {
    private final ReservaService reservaService;

    @GetMapping
    public ResponseEntity<List<ReservaDto>> list() {
        return ResponseEntity.ok(reservaService.listAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReservaDto> findById(@PathVariable("id") Integer id) {
        return ResponseEntity.ok(reservaService.findById(id));
    }

    @GetMapping("/filter")
    public ResponseEntity<List<ReservaDto>> findByGenreAndDates(@RequestParam GeneroPeliculaEnum genre,
                                                                @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss", iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
                                                                @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss", iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        return ResponseEntity.ok(reservaService.findByGeneroFecha(genre, startDate, endDate));
    }

    @PostMapping
    public ResponseEntity<ReservaDto> create(@RequestBody @Valid ReservaDto reservaDto) {
        ReservaDto createdClient = reservaService.create(reservaDto);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
                .buildAndExpand(createdClient.getIdReserva()).toUri();
        return ResponseEntity.created(location).build();
    }

    @PutMapping
    public ResponseEntity<ReservaDto> update(@RequestBody @Valid ReservaDto reservaDto) {
        return ResponseEntity.ok(reservaService.update(reservaDto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ReservaDto> delete(@PathVariable("id") Integer id) {
        reservaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
