create database cine;

use cine;

create table generador(
	Id int not null,
	NEXT_VAL int,
    SEQUENCE_NAME varchar(10) not null,
    Estado char(1) not null
);

create table reserva(
	IdReserva int not null primary key auto_increment,
    FechaReserva datetime not null,
    Estado char(1) not null,
    IdCliente int not null,
    IdAsiento int not null,
    IdCartelera int not null
);

create table asiento(
	IdAsiento int not null primary key auto_increment,
    NumeroAsiento int not null,
	NumeroFila int not null,
    IdSala int not null,
    Estado char(1) not null
);

create table cartelera(
	IdCartelera int not null primary key auto_increment,
    FechaPublicacion datetime not null,
    TiempoInicio datetime not null,
    TiempoFin datetime not null,
	Estado char(1) not null,
	IdPelicula int not null,
    IdSala int not null
);

create table pelicula(
	IdPelicula int not null primary key auto_increment,
    NombrePelicula varchar(100) not null,
    GeneroPelicula varchar(30) not null,
    EdadPermitida int not null,
	MinutosDuracion int not null,
	Estado char(1) not null
);

create table cliente(
	IdCliente int not null primary key auto_increment,
	Estado char(1) not null,
    Cedula varchar(10) not null,
    Nombre varchar(50) not null,
	Apellido varchar(50) not null,
    Edad int not null,
    Telefono varchar(10) not null,
    Correo varchar(25) not null
);

create table sala(
	IdSala int not null primary key auto_increment,
	NombreSala varchar(50) not null,
    NumeroSala int not null,
    Estado char(1) not null
);

alter table reserva
add constraint fk_reserva_cliente
foreign key(IdCliente)
references cliente(IdCliente);

alter table reserva
add constraint fk_reserva_asiento
foreign key(IdAsiento)
references asiento(IdAsiento);

alter table reserva
add constraint fk_reserva_cartelera
foreign key(IdCartelera)
references cartelera(IdCartelera);

alter table asiento
add constraint fk_asiento_sala
foreign key(IdSala)
references sala(IdSala);

alter table cartelera
add constraint fk_cartelera_pelicula
foreign key(IdPelicula)
references pelicula(IdPelicula);

alter table sala
add constraint fk_cartelera_sala
foreign key(IdSala)
references sala(IdSala);

insert into pelicula
values (1, 18, 'A', 'TERROR', 120, 'CHUCKY'),
       (2, 12, 'A', 'COMEDIA', 120, 'MI POBRE ANGELITO'),
       (3, 18, 'A', 'ACCION', 120, 'RAMBO');

insert into sala
values (1, 'A', 'SALA 1', 1),
       (2, 'A', 'SALA 2', 2),
       (3, 'A', 'SALA 3', 3);

insert into asiento
values (1, 'A', '1','3', 1),
       (2, 'A', '15', '6', 2),
       (3, 'A', '2', '10', 3);

UPDATE GENERADOR
SET NEXT_VAL = 4
WHERE SEQUENCE_NAME = 'pelicula';

UPDATE GENERADOR
SET NEXT_VAL = 4
WHERE SEQUENCE_NAME = 'sala';