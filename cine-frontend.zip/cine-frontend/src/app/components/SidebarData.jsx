import * as React from 'react';
import * as AiIcons from 'react-icons/ai';
import * as GiIcons from 'react-icons/gi';
import * as FaIcons from 'react-icons/fa';
import * as MdIcons from 'react-icons/md';
import * as IoIcons from "react-icons/io";

export const SidebarData = [
    {
        title: 'Inicio',
        path: '/',
        icon: <AiIcons.AiFillHome/>,
        cName: 'nav-text'
    },
    {
        title: 'Asientos Disponibles',
        path: '/asiento',
        icon: <MdIcons.MdEventSeat />,
        cName: 'nav-text'
    },
    {
        title: 'Cartelera de Cine',
        path: '/cartelera',
        icon: <FaIcons.FaListAlt />,
        cName: 'nav-text'
    },
    {
        title: 'Cliente',
        path: '/cliente',
        icon: <IoIcons.IoMdPeople />,
        cName: 'nav-text'
    },
    {
        title: 'Películas',
        path: '/pelicula',
        icon: <GiIcons.GiFilmSpool />,
        cName: 'nav-text'
    },
    {
        title: 'Reserva de Funciones',
        path: '/reserva',
        icon: <FaIcons.FaEdit/>,
        cName: 'nav-text'
    },
    {
        title: 'Salas de Cine',
        path: '/sala',
        icon: <FaIcons.FaDoorOpen />,
        cName: 'nav-text'
    },
]