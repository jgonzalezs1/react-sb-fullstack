import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import PeliculaService from '../../services/Pelicula.service';
import * as IoIcons from 'react-icons/io';
import * as RiIcons from 'react-icons/ri';
import { toast } from 'react-toastify';

class ListPeliculaComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            filtro: "",
            pelicula: []
        }
        this.addPelicula = this.addPelicula.bind(this);
        this.editPelicula = this.editPelicula.bind(this);
        this.deletePelicula = this.deletePelicula.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
    }

    addPelicula() {
        this.props.history.push('/pelicula/agregar-pelicula');
    }

    editPelicula(id) {
        this.props.history.push(`/pelicula/editar-pelicula/${id}`);
    }

    deletePelicula(id) {
        PeliculaService.deletePelicula(id).then(res => {
            this.setState({
                pelicula: this.state.pelicula.filter(pelicula => pelicula.idPelicula !== id)
            });
            console.log(res);
            toast.success("Se eliminó el registro", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    handleKeyPress(e) {
        this.setState({
            filtro: e.target.value
        })
    }

    componentDidMount() {
        PeliculaService.getPelicula().then(res => {
            this.setState({
                pelicula: res.data
            });
        });
    }

    render() {
        let { filtro, pelicula } = this.state;
        let search = pelicula.filter(item => {
            return Object.keys(item).some(key =>
                typeof item[key] === "string" && item[key].toLowerCase().includes(filtro.toLowerCase()))
        });
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        <h3 className="titulo">LISTADO DE PELÍCULAS EN EXHIBICIÓN</h3>
                        <div className="col-lg-6 offset-lg-5">
                            <button className="btn btn-primary" onClick={this.addPelicula}>Registrar Pelicula</button>
                        </div>
                    </div>
                    <div className="row mt-4">
                        <div className="col-lg-8 offset-lg-2">
                            <div className="row">
                                <Form.Control type="text" name="filtrar" className="form-control" value={filtro}
                                    onChange={this.handleKeyPress} placeholder="Buscar" />
                                <hr />
                                <table className="table table-striped table-bordered">
                                    <thead>
                                        <tr align="center">
                                            <th>CÓDIGO</th>
                                            <th>NOMBRE DE PELÍCULA</th>
                                            <th>GÉNERO DE PELÍCULA</th>
                                            <th>EDAD PERMITIDA</th>
                                            <th>MINUTOS DE DURACIÓN</th>
                                            <th>CARTELERA</th>
                                            <th>ACCIONES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            search.map(
                                                pelicula =>
                                                    <tr key={pelicula.idPelicula} align="center">
                                                        <td> {pelicula.idPelicula} </td>
                                                        <td> {pelicula.nombrePelicula} </td>
                                                        <td> {pelicula.generoPelicula} </td>
                                                        <td> {pelicula.edadPermitida} </td>
                                                        <td> {pelicula.minutosDuracion} </td>
                                                        <td> {pelicula.estado}</td>
                                                        <td>
                                                            <RiIcons.RiPencilFill onClick={() => this.editPelicula(pelicula.idPelicula)} />
                                                            <IoIcons.IoMdTrash style={{ marginLeft: "18px" }} onClick={() => this.deletePelicula(pelicula.idPelicula)} />
                                                        </td>
                                                    </tr>
                                            )
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ListPeliculaComponent;
