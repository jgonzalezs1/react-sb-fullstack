import React, { Component } from 'react';
import { Form, Button } from 'react-bootstrap';
import PeliculaService from '../../services/Pelicula.service';
import * as FaIcons from 'react-icons/fa';
import * as ImIcons from 'react-icons/im';
import { toast } from 'react-toastify';

var listOpciones = [
    { id: 1, value: 'E', descripcion: 'En Exhibición' },
    { id: 2, value: 'N', descripcion: 'No Disponible' },
]

class CreatePeliculaComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            nombrePelicula: "",
            generoPelicula: "",
            edadPermitida: 0,
            minutosDuracion: 0,
            estado: "",
            checked: false
        }

        this.changeNombrePelicula = this.changeNombrePelicula.bind(this);
        this.changeGeneroPelicula = this.changeGeneroPelicula.bind(this);
        this.changeEdadPermitida = this.changeEdadPermitida.bind(this);
        this.changeMinutosDuracion = this.changeMinutosDuracion.bind(this);
        this.changeEstado = this.changeEstado.bind(this);
        this.savePelicula = this.savePelicula.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    savePelicula = (event) => {
        event.preventDefault();
        let pelicula = {
            nombrePelicula: this.state.nombrePelicula,
            generoPelicula: this.state.generoPelicula,
            edadPermitida: this.state.edadPermitida,
            minutosDuracion: this.state.minutosDuracion,
            estado: this.state.estado
        }

        PeliculaService.createPelicula(pelicula).then(res => {
            console.log(res);
            this.props.history.push('/pelicula');
            toast.success("Transacción realizada con éxito", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    changeNombrePelicula = (event) => {
        this.setState({
            nombrePelicula: event.target.value
        });
    }

    changeGeneroPelicula = (event) => {
        this.setState({
            generoPelicula: event.target.value
        });
    }

    changeEdadPermitida = (event) => {
        this.setState({
            edadPermitida: event.target.value
        });
    }

    changeMinutosDuracion = (event) => {
        this.setState({
            minutosDuracion: event.target.value
        });
    }

    changeEstado = (event) => {
        this.setState({
            estado: event.target.value,
            checked: true
        });
    }

    cancel() {
        this.props.history.push('/pelicula');
    }

    getTitle() {
        return <h3 className="text-center">Registrar Película</h3>
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        {
                            this.getTitle()
                        }
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-lg-6 offset-lg-3">
                        <div className="card">
                            <div className="card-body">
                                <Form>
                                    <Form.Group className="mb-3" controlId="idPelicula">
                                        <Form.Label>Código</Form.Label>
                                        <Form.Control type="text" readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="nombrePelicula">
                                        <Form.Label>Nombre de Película</Form.Label>
                                        <Form.Control type="text" onChange={this.changeNombrePelicula} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="generoPelicula">
                                        <Form.Label>Género de Película</Form.Label>
                                        <Form.Control type="text" onChange={this.changeGeneroPelicula} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="edadPermitida">
                                        <Form.Label>Edad Permitida</Form.Label>
                                        <Form.Control type="number" min="1" max="100" onChange={this.changeEdadPermitida} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="minutosDuracion">
                                        <Form.Label>Minutos de Duración</Form.Label>
                                        <Form.Control type="number" min="1" max="360" onChange={this.changeMinutosDuracion} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="estado">
                                        <Form.Label>Estado</Form.Label>
                                        {
                                            listOpciones.map(opciones =>
                                                <Form.Check key={opciones.id} value={opciones.value} type="radio"
                                                    name={opciones} label={opciones.descripcion} onChange={this.changeEstado} />
                                            )
                                        }
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.savePelicula} variant="primary" type="submit">
                                        <FaIcons.FaSave />Grabar
                                    </Button>
                                    <Button className="btn btn-danger" onClick={this.cancel} style={{ marginLeft: "18px" }} variant="primary">
                                        <ImIcons.ImCancelCircle />Cancelar
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default CreatePeliculaComponent;