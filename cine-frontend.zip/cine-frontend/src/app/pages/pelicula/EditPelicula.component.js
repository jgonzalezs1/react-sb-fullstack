import React, { Component } from 'react';
import { Form, Button } from 'react-bootstrap';
import PeliculaService from '../../services/Pelicula.service';
import * as FaIcons from 'react-icons/fa';
import * as ImIcons from 'react-icons/im';
import { toast } from 'react-toastify';

class EditPeliculaComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            idPelicula: this.props.match.params.id,
            nombrePelicula: "",
            generoPelicula: "",
            edadPermitida: 0,
            minutosDuracion: 0,
            estado: ""
        }

        this.changeNombrePelicula = this.changeNombrePelicula.bind(this);
        this.changeGeneroPelicula = this.changeGeneroPelicula.bind(this);
        this.changeEdadPermitida = this.changeEdadPermitida.bind(this);
        this.changeMinutosDuracion = this.changeMinutosDuracion.bind(this);
        this.changeEstado = this.changeEstado.bind(this);
        this.savePelicula = this.savePelicula.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    componentDidMount() {
        PeliculaService.getPeliculaId(this.state.idPelicula).then(res => {
            let pelicula = res.data;
            this.setState({
                idPelicula: pelicula.idPelicula,
                nombrePelicula: pelicula.nombrePelicula,
                generoPelicula: pelicula.generoPelicula,
                edadPermitida: pelicula.edadPermitida,
                minutosDuracion: pelicula.minutosDuracion,
                estado: pelicula.estado
            });
        });
    }

    savePelicula = (event) => {
        event.preventDefault();
        let pelicula = {
            idPelicula: this.state.idPelicula,
            nombrePelicula: this.state.nombrePelicula,
            generoPelicula: this.state.generoPelicula,
            edadPermitida: this.state.edadPermitida,
            minutosDuracion: this.state.minutosDuracion,
            estado: this.state.estado
        }

        PeliculaService.editPelicula(pelicula).then(res => {
            console.log(res);
            this.props.history.push('/pelicula');
            toast.success("Transacción actualizada con éxito", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    changeNombrePelicula = (event) => {
        this.setState({
            nombrePelicula: event.target.value
        });
    }

    changeGeneroPelicula = (event) => {
        this.setState({
            generoPelicula: event.target.value
        });
    }

    changeEdadPermitida = (event) => {
        this.setState({
            edadPermitida: event.target.value
        });
    }

    changeMinutosDuracion = (event) => {
        this.setState({
            minutosDuracion: event.target.value
        });
    }

    changeEstado = (event) => {
        this.setState({
            estado: event
        });
    }

    cancel() {
        this.props.history.push('/pelicula');
    }

    getTitle() {
        return <h3 className="text-center">Actualizar Película</h3>
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        {
                            this.getTitle()
                        }
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-lg-6 offset-lg-3">
                        <div className="card">
                            <div className="card-body">
                                <Form>
                                    <Form.Group className="mb-3" controlId="idPelicula">
                                        <Form.Label>Código</Form.Label>
                                        <Form.Control value={this.state.idPelicula} type="text" readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="nombrePelicula">
                                        <Form.Label>Nombre de Película</Form.Label>
                                        <Form.Control type="text" value={this.state.nombrePelicula} onChange={this.changeNombrePelicula}  />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="generoPelicula">
                                        <Form.Label>Género de Película</Form.Label>
                                        <Form.Control type="text" value={this.state.generoPelicula} onChange={this.changeGeneroPelicula}  />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="edadPermitida">
                                        <Form.Label>Edad Permitida</Form.Label>
                                        <Form.Control type="number" min="1" max="100" value={this.state.edadPermitida} onChange={this.changeEdadPermitida}  />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="minutosDuracion">
                                        <Form.Label>Minutos de Duración</Form.Label>
                                        <Form.Control type="number" min="1" max="360" value={this.state.minutosDuracion} onChange={this.changeMinutosDuracion}  />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="estado">
                                        <Form.Label>Estado</Form.Label>
                                        <Form.Check type="radio" checked={this.state.estado === 'E'} onChange={() => this.changeEstado('E')} label="En Exhibición" />
                                        <Form.Check type="radio" checked={this.state.estado === 'N'} onChange={() => this.changeEstado('N')} label="No Disponible" />
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.savePelicula} variant="primary" type="submit">
                                        <FaIcons.FaSave />Grabar
                                    </Button>
                                    <Button className="btn btn-danger" onClick={this.cancel} style={{ marginLeft: "18px" }} variant="primary">
                                        <ImIcons.ImCancelCircle />Cancelar
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default EditPeliculaComponent;