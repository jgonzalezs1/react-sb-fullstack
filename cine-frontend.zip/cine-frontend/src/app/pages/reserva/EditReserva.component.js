import React, { Component } from 'react';
import { Form, Button } from 'react-bootstrap';
import ReservaService from '../../services/Reserva.service';
import ClienteService from '../../services/Cliente.service';
import AsientoService from '../../services/Asiento.service';
import CarteleraService from '../../services/Cartelera.service';
import * as FaIcons from 'react-icons/fa';
import * as ImIcons from 'react-icons/im';
import { toast } from 'react-toastify';

class EditReservaComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            idReserva: this.props.match.params.id,
            fechaReserva: "",
            idCliente: 0,
            idCartelera: 0,
            idAsiento: 0,
            estado: "",
            cliente: [],
            cartelera: [],
            asiento: [],
            selected: ""
        }

        this.changeFechaReserva = this.changeFechaReserva.bind(this);
        this.changeEstado = this.changeEstado.bind(this);
        this.changeCliente = this.changeCliente.bind(this);
        this.changeCartelera = this.changeCartelera.bind(this);
        this.changeAsiento = this.changeAsiento.bind(this);
        this.saveReserva = this.saveReserva.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    componentDidMount() {
        ReservaService.getReservaId(this.state.idReserva).then(res => {
            let reserva = res.data;
            this.setState({
                idReserva: reserva.idReserva,
                fechaReserva: reserva.fechaReserva,
                idCliente: reserva.idCliente,
                idCartelera: reserva.idCartelera,
                idAsiento: reserva.idAsiento,
                estado: reserva.estado
            });
        });

        ClienteService.getCliente().then(res => {
            this.setState({
                cliente: res.data
            });
        });

        CarteleraService.getCartelera().then(res => {
            this.setState({
                cartelera: res.data
            });
        });

        AsientoService.getAsiento().then(res => {
            this.setState({
                asiento: res.data
            });
        });
    }

    saveReserva = (event) => {
        event.preventDefault();
        let reserva = {
            idReserva: this.state.idReserva,
            fechaReserva: this.state.fechaReserva,
            idCliente: this.state.idCliente,
            idCartelera: this.state.idCartelera,
            idAsiento: this.state.idAsiento,
            estado: this.state.estado,
        }

        ReservaService.editReserva(reserva).then(res => {
            console.log(res);
            this.props.history.push('/reserva');
            toast.success("Transacción actualizada con éxito", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    changeFechaReserva = (event) => {
        this.setState({
            fechaReserva: event.target.value
        });
    }

    changeCliente = (event) => {
        this.setState({
            idCliente: event.target.value,
            selected: event.target.value
        });
    }

    changeCartelera = (event) => {
        this.setState({
            idCartelera: event.target.value,
            selected: event.target.value
        });
    }

    changeAsiento = (event) => {
        this.setState({
            idAsiento: event.target.value,
            selected: event.target.value
        });
    }

    changeEstado = (event) => {
        this.setState({
            estado: event
        });
    }

    cancel() {
        this.props.history.push('/reserva');
    }

    getTitle() {
        return <h3 className="text-center">Actualizar Reserva</h3>
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        {
                            this.getTitle()
                        }
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-lg-6 offset-lg-3">
                        <div className="card">
                            <div className="card-body">
                                <Form>
                                    <Form.Group className="mb-3" controlId="idReserva">
                                        <Form.Label>Código</Form.Label>
                                        <Form.Control value={this.state.idReserva} type="text" readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="fechaReserva">
                                        <Form.Label>Fecha de Reservación</Form.Label>
                                        <Form.Control type="datetime-local" value={this.state.fechaReserva} onChange={this.changeFechaReserva} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="idCliente">
                                        <Form.Label>Cliente</Form.Label>
                                        <Form.Select value={this.state.idCliente} onChange={this.changeCliente}>
                                            <option value=''>Seleccione</option>
                                            {
                                                this.state.cliente.map(opciones =>
                                                    <option value={opciones.idCliente} key={opciones.idCliente}>
                                                        {opciones.cedula}<p> - </p>{opciones.nombre} {opciones.apellido}
                                                    </option>
                                                )
                                            }
                                        </Form.Select>
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="idCartelera">
                                        <Form.Label>Cartelera</Form.Label>
                                        <Form.Select value={this.state.idCartelera} onChange={this.changeCartelera}>
                                            <option value=''>
                                                Seleccione
                                            </option>
                                            {
                                                this.state.cartelera.map(opciones =>
                                                    <option value={opciones.idCartelera} key={opciones.idCartelera}>
                                                        {opciones.nombrePelicula}<p> - </p>{opciones.generoPelicula}
                                                        <p> ({opciones.tiempoInicio}<p> - </p>{opciones.tiempoFin})</p>
                                                    </option>
                                                )
                                            }
                                        </Form.Select>
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="idAsiento">
                                        <Form.Label>Ubicación</Form.Label>
                                        <Form.Select value={this.state.idAsiento} onChange={this.changeAsiento}>
                                            <option value=''>
                                                Seleccione
                                            </option>
                                            {
                                                this.state.asiento.map(opciones =>
                                                    <option value={opciones.idAsiento} key={opciones.idAsiento}>
                                                        <p>FILA: </p>{opciones.numeroFila}<p> - </p>
                                                        <p>ASIENTO: </p>{opciones.numeroAsiento}
                                                    </option>
                                                )
                                            }
                                        </Form.Select>
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="estado">
                                        <Form.Label>Transacción</Form.Label>
                                        <Form.Check type="radio" checked={this.state.estado === 'R'} onChange={() => this.changeEstado('R')} label="Reservada" />
                                        <Form.Check type="radio" checked={this.state.estado === 'C'} onChange={() => this.changeEstado('C')} label="Cancelada" />
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.saveReserva} variant="primary" type="submit">
                                        <FaIcons.FaSave />Grabar
                                    </Button>
                                    <Button className="btn btn-danger" onClick={this.cancel} style={{ marginLeft: "18px" }} variant="primary">
                                        <ImIcons.ImCancelCircle />Cancelar
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default EditReservaComponent;