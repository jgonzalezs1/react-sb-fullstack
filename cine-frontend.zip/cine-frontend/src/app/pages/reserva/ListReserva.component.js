import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import ReservaService from '../../services/Reserva.service';
import * as IoIcons from 'react-icons/io';
import * as RiIcons from 'react-icons/ri';
import { toast } from 'react-toastify';

class ListReservaComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            filtro: "",
            reserva: []
        }
        this.addReserva = this.addReserva.bind(this);
        this.editReserva = this.editReserva.bind(this);
        this.deleteReserva = this.deleteReserva.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
    }

    addReserva() {
        this.props.history.push('/reserva/agregar-reserva');
    }

    editReserva(id) {
        this.props.history.push(`/reserva/editar-reserva/${id}`);
    }

    deleteReserva(id) {
        ReservaService.deleteReserva(id).then(res => {
            this.setState({
                reserva: this.state.reserva.filter(reserva => reserva.idReserva !== id)
            });
            console.log(res);
            toast.success("Se eliminó el registro", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    handleKeyPress(e) {
        this.setState({
            filtro: e.target.value
        })
    }

    componentDidMount() {
        ReservaService.getReserva().then(res => {
            this.setState({
                reserva: res.data
            });
        });
    }

    render() {
        let { filtro, reserva } = this.state;
        let search = reserva.filter(item => {
            return Object.keys(item).some(key =>
                typeof item[key] === "string" && item[key].toLowerCase().includes(filtro.toLowerCase()))
        });
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        <h3 className="titulo">LISTADO DE FUNCIONES RESERVADAS</h3>
                        <div className="col-lg-6 offset-lg-5">
                            <button className="btn btn-primary" onClick={this.addReserva}>Registrar Reserva</button>
                        </div>
                    </div>
                    <div className="row mt-4">
                        <div className="col-lg-8 offset-lg-2">
                            <div className="row">
                                <Form.Control type="text" name="filtrar" className="form-control" value={filtro}
                                    onChange={this.handleKeyPress} placeholder="Buscar" />
                                <hr />
                                <table className="table table-striped table-bordered">
                                    <thead>
                                        <tr align="center">
                                            <th>CÓDIGO</th>
                                            <th>FECHA DE RESERVA</th>
                                            <th>CLIENTE</th>
                                            <th>CARTELERA</th>
                                            <th>UBICACIÓN</th>
                                            <th>TRANSACCIÓN</th>
                                            <th>ACCIONES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            search.map(
                                                reserva =>
                                                    <tr key={reserva.idReserva} align="center">
                                                        <td> {reserva.idReserva} </td>
                                                        <td> {reserva.fechaReserva} </td>
                                                        <td> {reserva.datosCliente} </td>
                                                        <td> {reserva.datosCartelera} </td>
                                                        <td> {reserva.datosUbicacion} </td>
                                                        <td> {reserva.estado}</td>
                                                        <td>
                                                            <RiIcons.RiPencilFill onClick={() => this.editReserva(reserva.idReserva)} />
                                                            <IoIcons.IoMdTrash style={{ marginLeft: "18px" }} onClick={() => this.deleteReserva(reserva.idReserva)} />
                                                        </td>
                                                    </tr>
                                            )
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ListReservaComponent;
