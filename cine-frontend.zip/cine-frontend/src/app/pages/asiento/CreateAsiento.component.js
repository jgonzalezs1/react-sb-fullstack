import React, { Component } from 'react';
import { Form, Button } from 'react-bootstrap';
import AsientoService from '../../services/Asiento.service';
import * as FaIcons from 'react-icons/fa';
import * as ImIcons from 'react-icons/im';
import { toast } from 'react-toastify';
import SalaService from '../../services/Sala.service';

var listOpciones = [
    { id: 1, value: 'D', descripcion: 'Disponible' },
    { id: 2, value: 'O', descripcion: 'Ocupado' },
]

class CreateAsientoComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            numeroAsiento: 0,
            numeroFila: 0,
            idSala: 0,
            estado: "",
            sala: [],
            checked: false,
            selected: ""
        }

        this.changeNumeroAsiento = this.changeNumeroAsiento.bind(this);
        this.changeNumeroFila = this.changeNumeroFila.bind(this);
        this.changeSala = this.changeSala.bind(this);
        this.changeEstado = this.changeEstado.bind(this);
        this.saveAsiento = this.saveAsiento.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    saveAsiento = (event) => {
        event.preventDefault();
        let asiento = {
            numeroAsiento: this.state.numeroAsiento,
            numeroFila: this.state.numeroFila,
            idSala: this.state.idSala,
            estado: this.state.estado
        }

        AsientoService.createAsiento(asiento).then(res => {
            console.log(res);
            this.props.history.push('/asiento');
            toast.success("Transacción realizada con éxito", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    componentDidMount() {
        SalaService.getSala().then(res => {
            this.setState({
                sala: res.data
            });
        });
    }

    changeNumeroAsiento = (event) => {
        this.setState({
            numeroAsiento: event.target.value
        });
    }

    changeNumeroFila = (event) => {
        this.setState({
            numeroFila: event.target.value
        });
    }

    changeSala = (event) => {
        this.setState({
            idSala: event.target.value,
            selected: event.target.value
        });
    }

    changeEstado = (event) => {
        this.setState({
            estado: event.target.value,
            checked: true
        });
    }

    cancel() {
        this.props.history.push('/asiento');
    }

    getTitle() {
        return <h3 className="text-center">Registrar Asiento</h3>
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        {
                            this.getTitle()
                        }
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-lg-6 offset-lg-3">
                        <div className="card">
                            <div className="card-body">
                                <Form>
                                    <Form.Group className="mb-3" controlId="idAsiento">
                                        <Form.Label>Código</Form.Label>
                                        <Form.Control type="text" readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="nombreAsiento">
                                        <Form.Label>Número de Asiento</Form.Label>
                                        <Form.Control type="number" min="1" max="20" onChange={this.changeNumeroAsiento} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="numeroAsiento">
                                        <Form.Label>Número de Fila</Form.Label>
                                        <Form.Control type="number" min="1" max="10" onChange={this.changeNumeroFila} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="idSala">
                                        <Form.Label>Sala</Form.Label>
                                        <Form.Select onChange={this.changeSala}>
                                            <option value=''>Seleccione</option>
                                            {
                                                this.state.sala.map(opciones =>
                                                    <option value={opciones.idSala} key={opciones.idSala}>
                                                        {opciones.nombreSala}
                                                    </option>
                                                )
                                            }
                                        </Form.Select>
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="estado">
                                        <Form.Label>Espacio</Form.Label>
                                        {
                                            listOpciones.map(opciones =>
                                                <Form.Check key={opciones.id} value={opciones.value} type="radio"
                                                    name={opciones} label={opciones.descripcion} onChange={this.changeEstado} />
                                            )
                                        }
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.saveAsiento} variant="primary" type="submit">
                                        <FaIcons.FaSave />Grabar
                                    </Button>
                                    <Button className="btn btn-danger" onClick={this.cancel} style={{ marginLeft: "18px" }} variant="primary">
                                        <ImIcons.ImCancelCircle />Cancelar
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default CreateAsientoComponent;