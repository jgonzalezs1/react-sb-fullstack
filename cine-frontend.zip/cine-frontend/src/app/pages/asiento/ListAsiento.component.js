import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import AsientoService from '../../services/Asiento.service';
import * as IoIcons from 'react-icons/io';
import * as RiIcons from 'react-icons/ri';
import { toast } from 'react-toastify';

class ListAsientoComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            filtro: "",
            asiento: []
        }
        this.addAsiento = this.addAsiento.bind(this);
        this.editAsiento = this.editAsiento.bind(this);
        this.deleteAsiento = this.deleteAsiento.bind(this);
        this.patchAsiento = this.patchAsiento.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
    }

    addAsiento() {
        this.props.history.push('/asiento/agregar-asiento');
    }

    editAsiento(id) {
        this.props.history.push(`/asiento/editar-asiento/${id}`);
    }

    patchAsiento(id) {
        if(this.state.asiento[0].estado !== 'B'){
            this.props.history.push(`/asiento/inhabilitar-asiento/${id}`);
        }else{
            toast.error("Transacción parcialmente fallida", "Información del usuario");
        }
    }

    deleteAsiento(id) {
        AsientoService.deleteAsiento(id).then(res => {
            this.setState({
                asiento: this.state.asiento.filter(asiento => asiento.idAsiento !== id)
            });
            console.log(res);
            toast.success("Se eliminó el registro", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    } 

    handleKeyPress(e) {
        this.setState({
            filtro: e.target.value
        })
    }

    componentDidMount() {
        AsientoService.getAsiento().then(res => {
            this.setState({
                asiento: res.data
            });
        });
    }

    render() {
        let { filtro, asiento } = this.state;
        let search = asiento.filter(item => {
            return Object.keys(item).some(key =>
                typeof item[key] === "string" && item[key].toLowerCase().includes(filtro.toLowerCase()))
        });
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        <h3 className="titulo">LISTADO DE ASIENTOS DISPONIBLES</h3>
                        <div className="col-lg-6 offset-lg-5">
                            <button className="btn btn-primary" onClick={this.addAsiento}>Registrar Asiento</button>
                        </div>
                    </div>
                    <div className="row mt-4">
                        <div className="col-lg-8 offset-lg-2">
                            <div className="row">
                                <Form.Control type="text" name="filtrar" className="form-control" value={filtro}
                                    onChange={this.handleKeyPress} placeholder="Buscar" />
                                <hr />
                                <table className="table table-striped table-bordered">
                                    <thead>
                                        <tr align="center">
                                            <th>CÓDIGO</th>
                                            <th>NÚMERO DE ASIENTO</th>
                                            <th>NÚMERO DE FILA</th>
                                            <th>SALA</th>
                                            <th>ESPACIO</th>
                                            <th>ACCIONES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            search.map(
                                                asiento =>
                                                    <tr key={asiento.idAsiento} align="center">
                                                        <td> {asiento.idAsiento} </td>
                                                        <td> {asiento.numeroAsiento} </td>
                                                        <td> {asiento.numeroFila} </td>
                                                        <td> {asiento.nombreSala} </td>
                                                        <td> {asiento.estado}</td>
                                                        <td>
                                                            <RiIcons.RiPencilFill onClick={() => this.editAsiento(asiento.idAsiento)} />
                                                            <RiIcons.RiEditCircleLine style={{ marginLeft: "18px" }} onClick={() => this.patchAsiento(asiento.idAsiento)} />
                                                            <IoIcons.IoMdTrash style={{ marginLeft: "18px" }} onClick={() => this.deleteAsiento(asiento.idAsiento)} />
                                                        </td>
                                                    </tr>
                                            )
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ListAsientoComponent;
