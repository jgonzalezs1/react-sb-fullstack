import React, { Component } from 'react';
import { Form, Button } from 'react-bootstrap';
import AsientoService from '../../services/Asiento.service';
import SalaService from '../../services/Sala.service';
import * as FaIcons from 'react-icons/fa';
import * as ImIcons from 'react-icons/im';
import { toast } from 'react-toastify';

class PatchAsientoComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            idAsiento: this.props.match.params.id,
            numeroAsiento: 0,
            numeroFila: 0,
            idSala: 0,
            estado: "",
            sala: [],
            selected: ""
        }

        this.changeNumeroAsiento = this.changeNumeroAsiento.bind(this);
        this.changeNumeroFila = this.changeNumeroFila.bind(this);
        this.changeSala = this.changeSala.bind(this);
        this.changeEstado = this.changeEstado.bind(this);
        this.saveAsiento = this.saveAsiento.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    componentDidMount() {
        AsientoService.getAsientoId(this.state.idAsiento).then(res => {
            let asiento = res.data;
            this.setState({
                idAsiento: asiento.idAsiento,
                numeroAsiento: asiento.numeroAsiento,
                numeroFila: asiento.numeroFila,
                idSala: asiento.idSala,
                estado: asiento.estado
            });
        });
        
        SalaService.getSala().then(res => {
            this.setState({
                sala: res.data
            });
        });
    }

    saveAsiento = (event) => {
        event.preventDefault();
        let asiento = {
            idAsiento: this.state.idAsiento,
            numeroAsiento: this.state.numeroAsiento,
            numeroFila: this.state.numeroFila,
            idSala: this.state.idSala,
            estado: this.state.estado
        }

        AsientoService.patchAsiento(asiento.idAsiento).then(res => {
            console.log(res);
            this.props.history.push('/asiento');
            toast.success("Transacción parcialmente actualizada con éxito", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    changeNumeroAsiento = (event) => {
        this.setState({
            numeroAsiento: event.target.value
        });
    }

    changeNumeroFila = (event) => {
        this.setState({
            numeroFila: event.target.value
        });
    }

    changeSala = (event) => {
        this.setState({
            idSala: event.target.value,
            selected: event.target.value
        });
    }

    changeEstado = (event) => {
        this.setState({
            estado: event
        });
    }

    cancel() {
        this.props.history.push('/asiento');
    }

    getTitle() {
        return <h3 className="text-center">Bloquear Asiento</h3>
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        {
                            this.getTitle()
                        }
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-lg-6 offset-lg-3">
                        <div className="card">
                            <div className="card-body">
                                <Form>
                                    <Form.Group className="mb-3" controlId="idAsiento">
                                        <Form.Label>Código</Form.Label>
                                        <Form.Control value={this.state.idAsiento} type="text" readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="numeroAsiento">
                                        <Form.Label>Número de Asiento</Form.Label>
                                        <Form.Control type="number" value={this.state.numeroAsiento} onChange={this.changeNumeroAsiento} readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="numeroFila">
                                        <Form.Label>Número de Fila</Form.Label>
                                        <Form.Control type="number" value={this.state.numeroFila} onChange={this.changeNumeroFila} readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="idSala">
                                        <Form.Label>Sala</Form.Label>
                                        <Form.Select value={this.state.idSala} onChange={this.changeSala} disabled>
                                            <option value=''>Seleccione</option>
                                            {
                                                this.state.sala.map(opciones =>
                                                    <option value={opciones.idSala} key={opciones.idSala}>
                                                        {opciones.nombreSala}
                                                    </option>
                                                )
                                            }
                                        </Form.Select>
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="estado">
                                        <Form.Label>Espacio</Form.Label>
                                        <Form.Check type="radio" checked={this.state.estado === 'D'} onChange={() => this.changeEstado('D')} label="Disponible" disabled />
                                        <Form.Check type="radio" checked={this.state.estado === 'O'} onChange={() => this.changeEstado('O')} label="Ocupado" disabled />
                                        <Form.Check type="radio" checked={this.state.estado === 'B'} onChange={() => this.changeEstado('B')} label="Bloqueado" />    
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.saveAsiento} variant="primary" type="submit">
                                        <FaIcons.FaSave />Grabar
                                    </Button>
                                    <Button className="btn btn-danger" onClick={this.cancel} style={{ marginLeft: "18px" }} variant="primary">
                                        <ImIcons.ImCancelCircle />Cancelar
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default PatchAsientoComponent;