import React, { Component } from 'react';
import { Form, Button } from 'react-bootstrap';
import ClienteService from '../../services/Cliente.service';
import * as FaIcons from 'react-icons/fa';
import * as ImIcons from 'react-icons/im';
import { toast } from 'react-toastify';

class EditClienteComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            idCliente: this.props.match.params.id,
            cedula: "",
            nombre: "",
            apellido: "",
            edad: 0,
            telefono: "",
            correo: "",
            estado: ""
        }

        this.changeCedula = this.changeCedula.bind(this);
        this.changeNombre = this.changeNombre.bind(this);
        this.changeApellido = this.changeApellido.bind(this);
        this.changeEdad = this.changeEdad.bind(this);
        this.changeTelefono = this.changeTelefono.bind(this);
        this.changeCorreo = this.changeCorreo.bind(this);
        this.changeEstado = this.changeEstado.bind(this);
        this.saveCliente = this.saveCliente.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    componentDidMount() {
        ClienteService.getClienteId(this.state.idCliente).then(res => {
            let cliente = res.data;
            this.setState({
                idCliente: cliente.idCliente,
                cedula: cliente.cedula,
                nombre: cliente.nombre,
                apellido: cliente.apellido,
                edad: cliente.edad,
                telefono: cliente.telefono,
                correo: cliente.correo,
                estado: cliente.estado
            });
        });
    }

    saveCliente = (event) => {
        event.preventDefault();
        let cliente = {
            idCliente: this.state.idCliente,
            cedula: this.state.cedula,
            nombre: this.state.nombre,
            apellido: this.state.apellido,
            edad: this.state.edad,
            telefono: this.state.telefono,
            correo: this.state.correo,
            estado: this.state.estado
        }

        ClienteService.editCliente(cliente).then(res => {
            console.log(res);
            this.props.history.push('/cliente');
            toast.success("Transacción actualizada con éxito", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    changeCedula = (event) => {
        this.setState({
            cedula: event.target.value
        });
    }

    changeNombre = (event) => {
        this.setState({
            nombre: event.target.value
        });
    }

    changeApellido = (event) => {
        this.setState({
            apellido: event.target.value
        });
    }

    changeEdad = (event) => {
        this.setState({
            edad: event.target.value
        });
    }

    changeTelefono = (event) => {
        this.setState({
            telefono: event.target.value
        });
    }

    changeCorreo = (event) => {
        this.setState({
            correo: event.target.value
        });
    }

    changeEstado = (event) => {
        this.setState({
            estado: event
        });
    }

    cancel() {
        this.props.history.push('/cliente');
    }

    getTitle() {
        return <h3 className="text-center">Actualizar Cliente</h3>
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        {
                            this.getTitle()
                        }
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-lg-6 offset-lg-3">
                        <div className="card">
                            <div className="card-body">
                                <Form>
                                    <Form.Group className="mb-3" controlId="idCliente">
                                        <Form.Label>Código</Form.Label>
                                        <Form.Control value={this.state.idCliente} type="text" readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="cedula">
                                        <Form.Label>Cédula</Form.Label>
                                        <Form.Control type="text" value={this.state.cedula} onChange={this.changeCedula} maxLength="10" />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="nombre">
                                        <Form.Label>Nombre</Form.Label>
                                        <Form.Control type="text" value={this.state.nombre} onChange={this.changeNombre} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="apellido">
                                        <Form.Label>Apellido</Form.Label>
                                        <Form.Control type="text" value={this.state.apellido} onChange={this.changeApellido} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="edad">
                                        <Form.Label>Edad</Form.Label>
                                        <Form.Control type="number" min="1" max="100" value={this.state.edad} onChange={this.changeEdad} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="telefono">
                                        <Form.Label>Teléfono</Form.Label>
                                        <Form.Control type="text" value={this.state.telefono} onChange={this.changeTelefono} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="correo">
                                        <Form.Label>Correo</Form.Label>
                                        <Form.Control type="text" value={this.state.correo} onChange={this.changeCorreo} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="estado">
                                        <Form.Label>Estado</Form.Label>
                                        <Form.Check type="radio" checked={this.state.estado === 'A'} onChange={() => this.changeEstado('A')} label="Activo" />
                                        <Form.Check type="radio" checked={this.state.estado === 'I'} onChange={() => this.changeEstado('I')} label="Inactivo" />
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.saveCliente} variant="primary" type="submit">
                                        <FaIcons.FaSave />Grabar
                                    </Button>
                                    <Button className="btn btn-danger" onClick={this.cancel} style={{ marginLeft: "18px" }} variant="primary">
                                        <ImIcons.ImCancelCircle />Cancelar
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default EditClienteComponent;