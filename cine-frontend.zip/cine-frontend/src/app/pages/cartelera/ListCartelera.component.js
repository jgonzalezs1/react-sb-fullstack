import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import CarteleraService from '../../services/Cartelera.service';
import * as IoIcons from 'react-icons/io';
import * as RiIcons from 'react-icons/ri';
import { toast } from 'react-toastify';

class ListCarteleraComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            filtro: "",
            cartelera: []
        }
        this.addCartelera = this.addCartelera.bind(this);
        this.editCartelera = this.editCartelera.bind(this);
        this.deleteCartelera = this.deleteCartelera.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
    }

    addCartelera() {
        this.props.history.push('/cartelera/agregar-cartelera');
    }

    editCartelera(id) {
        this.props.history.push(`/cartelera/editar-cartelera/${id}`);
    }

    deleteCartelera(id) {
        CarteleraService.deleteCartelera(id).then(res => {
            this.setState({
                cartelera: this.state.cartelera.filter(cartelera => cartelera.idCartelera !== id)
            });
            console.log(res);
            toast.success("Se eliminó el registro", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    handleKeyPress(e) {
        this.setState({
            filtro: e.target.value
        })
    }

    componentDidMount() {
        CarteleraService.getCartelera().then(res => {
            this.setState({
                cartelera: res.data
            });
        });
    }

    render() {
        let { filtro, cartelera } = this.state;
        let search = cartelera.filter(item => {
            return Object.keys(item).some(key =>
                typeof item[key] === "string" && item[key].toLowerCase().includes(filtro.toLowerCase()))
        });
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        <h3 className="titulo">LISTADO DE CARTELERAS DE CINE</h3>
                        <div className="col-lg-6 offset-lg-5">
                            <button className="btn btn-primary" onClick={this.addCartelera}>Registrar Cartelera</button>
                        </div>
                    </div>
                    <div className="row mt-4">
                        <div className="col-lg-8 offset-lg-2">
                            <div className="row">
                                <Form.Control type="text" name="filtrar" className="form-control" value={filtro}
                                    onChange={this.handleKeyPress} placeholder="Buscar" />
                                <hr />
                                <table className="table table-striped table-bordered">
                                    <thead>
                                        <tr align="center">
                                            <th>CÓDIGO</th>
                                            <th>FECHA DE ESTRENO</th>
                                            <th>PELÍCULA</th>
                                            <th>GÉNERO</th>
                                            <th>SALA</th>
                                            <th>HORA DE INICIO</th>
                                            <th>HORA DE FIN</th>
                                            <th>FUNCIÓN</th>
                                            <th>ACCIONES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            search.map(
                                                cartelera =>
                                                    <tr key={cartelera.idCartelera} align="center">
                                                        <td> {cartelera.idCartelera} </td>
                                                        <td> {cartelera.fechaPublicacion} </td>
                                                        <td> {cartelera.nombrePelicula} </td>
                                                        <td> {cartelera.generoPelicula} </td>
                                                        <td> {cartelera.nombreSala} </td>
                                                        <td> {cartelera.tiempoInicio} </td>
                                                        <td> {cartelera.tiempoFin} </td>
                                                        <td> {cartelera.estado}</td>
                                                        <td>
                                                            <RiIcons.RiPencilFill onClick={() => this.editCartelera(cartelera.idCartelera)} />
                                                            <IoIcons.IoMdTrash style={{ marginLeft: "18px" }} onClick={() => this.deleteCartelera(cartelera.idCartelera)} />
                                                        </td>
                                                    </tr>
                                            )
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ListCarteleraComponent;
