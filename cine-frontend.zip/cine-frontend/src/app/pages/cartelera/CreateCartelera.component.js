import React, { Component } from 'react';
import { Form, Button } from 'react-bootstrap';
import CarteleraService from '../../services/Cartelera.service';
import PeliculaService from '../../services/Pelicula.service';
import SalaService from '../../services/Sala.service';
import * as FaIcons from 'react-icons/fa';
import * as ImIcons from 'react-icons/im';
import { toast } from 'react-toastify';

var listOpciones = [
    { id: 1, value: 'M', descripcion: 'Mañana' },
    { id: 2, value: 'T', descripcion: 'Tarde' },
    { id: 3, value: 'N', descripcion: 'Noche' },
]

class CreateCarteleraComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            fechaPublicacion: "",
            tiempoInicio: "",
            tiempoFin: "",
            idPelicula: 0,
            idSala: 0,
            estado: "",
            pelicula: [],
            sala: [],
            checked: false,
            selected: ""
        }

        this.changeFechaPublicacion = this.changeFechaPublicacion.bind(this);
        this.changeTiempoInicio = this.changeTiempoInicio.bind(this);
        this.changeTiempoFin = this.changeTiempoFin.bind(this);
        this.changeEstado = this.changeEstado.bind(this);
        this.changePelicula = this.changePelicula.bind(this);
        this.changeSala = this.changeSala.bind(this);
        this.saveCartelera = this.saveCartelera.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    saveCartelera = (event) => {
        event.preventDefault();
        let cartelera = {
            fechaPublicacion: this.state.fechaPublicacion,
            tiempoInicio: this.state.tiempoInicio,
            tiempoFin: this.state.tiempoFin,
            idPelicula: this.state.idPelicula,
            idSala: this.state.idSala,
            estado: this.state.estado
        }

        CarteleraService.createCartelera(cartelera).then(res => {
            console.log(res);
            this.props.history.push('/cartelera');
            toast.success("Transacción realizada con éxito", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    componentDidMount() {
        PeliculaService.getPelicula().then(res => {
            this.setState({
                pelicula: res.data
            });
        });

        SalaService.getSala().then(res => {
            this.setState({
                sala: res.data
            });
        });
    }

    changeFechaPublicacion = (event) => {
        this.setState({
            fechaPublicacion: event.target.value
        });
    }

    changeTiempoInicio = (event) => {
        this.setState({
            tiempoInicio: event.target.value
        });
    }

    changeTiempoFin = (event) => {
        this.setState({
            tiempoFin: event.target.value
        });
    }

    changePelicula = (event) => {
        this.setState({
            idPelicula: event.target.value,
            selected: event.target.value
        });
    }

    changeSala = (event) => {
        this.setState({
            idSala: event.target.value,
            selected: event.target.value
        });
    }

    changeEstado = (event) => {
        this.setState({
            estado: event.target.value,
            checked: true
        });
    }

    cancel() {
        this.props.history.push('/cartelera');
    }

    getTitle() {
        return <h3 className="text-center">Registrar Cartelera</h3>
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        {
                            this.getTitle()
                        }
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-lg-6 offset-lg-3">
                        <div className="card">
                            <div className="card-body">
                                <Form>
                                    <Form.Group className="mb-3" controlId="idCartelera">
                                        <Form.Label>Código</Form.Label>
                                        <Form.Control type="text" readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="FechaPublicacion">
                                        <Form.Label>Fecha de Estreno</Form.Label>
                                        <Form.Control type="date" onChange={this.changeFechaPublicacion} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="idPelicula">
                                        <Form.Label>Pelicula</Form.Label>
                                        <Form.Select onChange={this.changePelicula}>
                                            <option value=''>Seleccione</option>
                                            {
                                                this.state.pelicula.map(opciones =>
                                                    <option value={opciones.idPelicula} key={opciones.idPelicula}>
                                                        {opciones.nombrePelicula}
                                                    </option>
                                                )
                                            }
                                        </Form.Select>
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="idSala">
                                        <Form.Label>Sala</Form.Label>
                                        <Form.Select onChange={this.changeSala}>
                                            <option value=''>Seleccione</option>
                                            {
                                                this.state.sala.map(opciones =>
                                                    <option value={opciones.idSala} key={opciones.idSala}>
                                                        {opciones.nombreSala}
                                                    </option>
                                                )
                                            }
                                        </Form.Select>
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="TiempoInicio">
                                        <Form.Label>Hora de Inicio</Form.Label>
                                        <Form.Control type="time" onChange={this.changeTiempoInicio} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="TiempoFin">
                                        <Form.Label>Hora de Fin</Form.Label>
                                        <Form.Control type="time" onChange={this.changeTiempoFin} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="estado">
                                        <Form.Label>Función</Form.Label>
                                        {
                                            listOpciones.map(opciones =>
                                                <Form.Check key={opciones.id} value={opciones.value} type="radio"
                                                    name={opciones} label={opciones.descripcion} onChange={this.changeEstado} />
                                            )
                                        }
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.saveCartelera} variant="primary" type="submit">
                                        <FaIcons.FaSave />Grabar
                                    </Button>
                                    <Button className="btn btn-danger" onClick={this.cancel} style={{ marginLeft: "18px" }} variant="primary">
                                        <ImIcons.ImCancelCircle />Cancelar
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default CreateCarteleraComponent;