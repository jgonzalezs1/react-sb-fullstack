import React, { Component } from 'react';
import { Form, Button } from 'react-bootstrap';
import CarteleraService from '../../services/Cartelera.service';
import PeliculaService from '../../services/Pelicula.service';
import SalaService from '../../services/Sala.service';
import * as FaIcons from 'react-icons/fa';
import * as ImIcons from 'react-icons/im';
import { toast } from 'react-toastify';

class EditCarteleraComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            idCartelera: this.props.match.params.id,
            fechaPublicacion: "",
            tiempoInicio: "",
            tiempoFin: "",
            idPelicula: 0,
            idSala: 0,
            estado: "",
            pelicula: [],
            sala: [],
            selected: ""
        }

        this.changeFechaPublicacion = this.changeFechaPublicacion.bind(this);
        this.changeTiempoInicio = this.changeTiempoInicio.bind(this);
        this.changeTiempoFin = this.changeTiempoFin.bind(this);
        this.changePelicula = this.changePelicula.bind(this);
        this.changeSala = this.changeSala.bind(this);
        this.changeEstado = this.changeEstado.bind(this);
        this.saveCartelera = this.saveCartelera.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    componentDidMount() {
        CarteleraService.getCarteleraId(this.state.idCartelera).then(res => {
            let cartelera = res.data;
            this.setState({
                idCartelera: cartelera.idCartelera,
                fechaPublicacion: cartelera.fechaPublicacion,
                tiempoInicio: cartelera.tiempoInicio,
                tiempoFin: cartelera.tiempoFin,
                idPelicula: cartelera.idPelicula,
                idSala: cartelera.idSala,
                estado: cartelera.estado
            });
        });

        PeliculaService.getPelicula().then(res => {
            this.setState({
                pelicula: res.data
            });
        });

        SalaService.getSala().then(res => {
            this.setState({
                sala: res.data
            });
        });
    }

    saveCartelera = (event) => {
        event.preventDefault();
        let cartelera = {
            idCartelera: this.state.idCartelera,
            fechaPublicacion: this.state.fechaPublicacion,
            tiempoInicio: this.state.tiempoInicio,
            tiempoFin: this.state.tiempoFin,
            idPelicula: this.state.idPelicula,
            idSala: this.state.idSala,
            estado: this.state.estado
        }

        CarteleraService.editCartelera(cartelera).then(res => {
            console.log(res);
            this.props.history.push('/cartelera');
            toast.success("Transacción actualizada con éxito", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    changeFechaPublicacion = (event) => {
        this.setState({
            fechaPublicacion: event.target.value
        });
    }

    changeTiempoInicio = (event) => {
        this.setState({
            tiempoInicio: event.target.value
        });
    }

    changeTiempoFin = (event) => {
        this.setState({
            tiempoFin: event.target.value
        });
    }

    changePelicula = (event) => {
        this.setState({
            idPelicula: event.target.value,
            selected: event.target.value
        });
    }

    changeSala = (event) => {
        this.setState({
            idSala: event.target.value,
            selected: event.target.value
        });
    }

    changeEstado = (event) => {
        this.setState({
            estado: event
        });
    }

    cancel() {
        this.props.history.push('/cartelera');
    }

    getTitle() {
        return <h3 className="text-center">Actualizar Cartelera</h3>
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        {
                            this.getTitle()
                        }
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-lg-6 offset-lg-3">
                        <div className="card">
                            <div className="card-body">
                                <Form>
                                    <Form.Group className="mb-3" controlId="idCartelera">
                                        <Form.Label>Código</Form.Label>
                                        <Form.Control value={this.state.idCartelera} type="text" readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="fechaPublicacion">
                                        <Form.Label>Fecha de Estreno</Form.Label>
                                        <Form.Control type="date" value={this.state.fechaPublicacion} onChange={this.changeFechaPublicacion} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="idPelicula">
                                        <Form.Label>Película</Form.Label>
                                        <Form.Select value={this.state.idPelicula} onChange={this.changePelicula}>
                                            <option value=''>Seleccione</option>
                                            {
                                                this.state.pelicula.map(opciones =>
                                                    <option value={opciones.idPelicula} key={opciones.idPelicula}>
                                                        {opciones.nombrePelicula}
                                                    </option>
                                                )
                                            }
                                        </Form.Select>
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="idSala">
                                        <Form.Label>Sala</Form.Label>
                                        <Form.Select value={this.state.idSala} onChange={this.changeSala}>
                                            <option value=''>Seleccione</option>
                                            {
                                                this.state.sala.map(opciones =>
                                                    <option value={opciones.idSala} key={opciones.idSala}>
                                                        {opciones.nombreSala}
                                                    </option>
                                                )
                                            }
                                        </Form.Select>
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="tiempoInicio">
                                        <Form.Label>Hora de Inicio</Form.Label>
                                        <Form.Control type="time" value={this.state.tiempoInicio} onChange={this.changeTiempoInicio} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="tiempoFin">
                                        <Form.Label>Hora de Fin</Form.Label>
                                        <Form.Control type="time" value={this.state.tiempoFin} onChange={this.changeTiempoFin} />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="estado">
                                        <Form.Label>Función</Form.Label>
                                        <Form.Check type="radio" checked={this.state.estado === 'M'} onChange={() => this.changeEstado('M')} label="Mañana" />
                                        <Form.Check type="radio" checked={this.state.estado === 'T'} onChange={() => this.changeEstado('T')} label="Tarde" />
                                        <Form.Check type="radio" checked={this.state.estado === 'N'} onChange={() => this.changeEstado('N')} label="Noche" />
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.saveCartelera} variant="primary" type="submit">
                                        <FaIcons.FaSave />Grabar
                                    </Button>
                                    <Button className="btn btn-danger" onClick={this.cancel} style={{ marginLeft: "18px" }} variant="primary">
                                        <ImIcons.ImCancelCircle />Cancelar
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default EditCarteleraComponent;