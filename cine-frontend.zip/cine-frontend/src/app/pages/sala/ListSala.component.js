import React, { Component } from 'react'
import { Form } from 'react-bootstrap';
import SalaService from '../../services/Sala.service';
import * as IoIcons from 'react-icons/io';
import * as RiIcons from 'react-icons/ri';
import { toast } from 'react-toastify';

class ListSalaComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            filtro: "",
            sala: []
        }
        this.addSala = this.addSala.bind(this);
        this.editSala = this.editSala.bind(this);
        this.deleteSala = this.deleteSala.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
    }

    addSala() {
        this.props.history.push('/sala/agregar-sala');
    }

    editSala(id) {
        this.props.history.push(`/sala/editar-sala/${id}`);
    }

    deleteSala(id) {
        SalaService.deleteSala(id).then(res => {
            this.setState({
                sala: this.state.sala.filter(sala => sala.idSala !== id)
            });
            console.log(res);
            toast.success("Se eliminó el registro", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    handleKeyPress(e) {
        this.setState({
            filtro: e.target.value
        })
    }

    componentDidMount() {
        SalaService.getSala().then(res => {
            this.setState({
                sala: res.data
            });
        });
    }

    render() {
        let { filtro, sala } = this.state;
        let search = sala.filter(item => {
            return Object.keys(item).some(key =>
                typeof item[key] === "string" && item[key].toLowerCase().includes(filtro.toLowerCase()))
        });
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        <h3 className="titulo">LISTADO DE SALAS DISPONIBLES</h3>
                        <div className="col-lg-6 offset-lg-5">
                            <button className="btn btn-primary" onClick={this.addSala}>Registrar Sala</button>
                        </div>
                    </div>
                    <div className="row mt-4">
                        <div className="col-lg-8 offset-lg-2">
                            <div className="row">
                                <Form.Control type="text" name="filtrar" className="form-control" value={filtro}
                                    onChange={this.handleKeyPress} placeholder="Buscar" />
                                <hr />
                                <table className="table table-striped table-bordered">
                                    <thead>
                                        <tr align="center">
                                            <th>CÓDIGO</th>
                                            <th>NOMBRE DE SALA</th>
                                            <th>NÚMERO DE SALA</th>
                                            <th>DISPONIBILIDAD</th>
                                            <th>ACCIONES</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            search.map(
                                                sala =>
                                                    <tr key={sala.idSala} align="center">
                                                        <td> {sala.idSala} </td>
                                                        <td> {sala.nombreSala} </td>
                                                        <td> {sala.numeroSala} </td>
                                                        <td> {sala.estado}</td>
                                                        <td>
                                                            <RiIcons.RiPencilFill onClick={() => this.editSala(sala.idSala)} />
                                                            <IoIcons.IoMdTrash style={{ marginLeft: "18px" }} onClick={() => this.deleteSala(sala.idSala)} />
                                                        </td>
                                                    </tr>
                                            )
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ListSalaComponent;
