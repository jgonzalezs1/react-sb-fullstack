import React, { Component } from 'react';
import { Form, Button } from 'react-bootstrap';
import SalaService from '../../services/Sala.service';
import * as FaIcons from 'react-icons/fa';
import * as ImIcons from 'react-icons/im';
import { toast } from 'react-toastify';

class EditSalaComponent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            idSala: this.props.match.params.id,
            nombreSala: "",
            numeroSala: 0,
            estado: ""
        }

        this.changeNombreSala = this.changeNombreSala.bind(this);
        this.changeNumeroSala = this.changeNumeroSala.bind(this);
        this.changeEstado = this.changeEstado.bind(this);
        this.saveSala = this.saveSala.bind(this);
        this.cancel = this.cancel.bind(this);
    }

    componentDidMount() {
        SalaService.getSalaId(this.state.idSala).then(res => {
            let sala = res.data;
            this.setState({
                idSala: sala.idSala,
                nombreSala: sala.nombreSala,
                numeroSala: sala.numeroSala,
                estado: sala.estado
            });
        });
    }

    saveSala = (event) => {
        event.preventDefault();
        let sala = {
            idSala: this.state.idSala,
            nombreSala: this.state.nombreSala,
            numeroSala: this.state.numeroSala,
            estado: this.state.estado
        }

        SalaService.editSala(sala).then(res => {
            console.log(res);
            this.props.history.push('/sala');
            toast.success("Transacción actualizada con éxito", "Información del usuario");
        }, err => {
            console.log(err);
            toast.error("Transacción fallida", "Información del usuario");
        });
    }

    changeNombreSala = (event) => {
        this.setState({
            nombreSala: event.target.value
        });
    }

    changeNumeroSala = (event) => {
        this.setState({
            numeroSala: event.target.value
        });
    }

    changeEstado = (event) => {
        this.setState({
            estado: event
        });
    }

    cancel() {
        this.props.history.push('/sala');
    }

    getTitle() {
        return <h3 className="text-center">Actualizar Sala</h3>
    }

    render() {
        return (
            <div className="container mt-5">
                <div className="row">
                    <div className="col-lg-8 offset-lg-2">
                        {
                            this.getTitle()
                        }
                    </div>
                </div>
                <div className="row mt-4">
                    <div className="col-lg-6 offset-lg-3">
                        <div className="card">
                            <div className="card-body">
                                <Form>
                                    <Form.Group className="mb-3" controlId="idSala">
                                        <Form.Label>Código</Form.Label>
                                        <Form.Control value={this.state.idSala} type="text" readOnly />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="nombreSala">
                                        <Form.Label>Nombre de la Sala</Form.Label>
                                        <Form.Control type="text" value={this.state.nombreSala} onChange={this.changeNombreSala}  />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="numeroSala">
                                        <Form.Label>Número de Sala</Form.Label>
                                        <Form.Control type="number" min="1" max="10" value={this.state.numeroSala} onChange={this.changeNumeroSala}  />
                                    </Form.Group>
                                    <Form.Group className="mb-3" controlId="estado">
                                        <Form.Label>Disponibilidad</Form.Label>
                                        <Form.Check type="radio" checked={this.state.estado === 'A'} onChange={() => this.changeEstado('A')} label="Abierta" />
                                        <Form.Check type="radio" checked={this.state.estado === 'C'} onChange={() => this.changeEstado('C')} label="Cerrada" />
                                    </Form.Group>
                                    <Button className="btn btn-success" onClick={this.saveSala} variant="primary" type="submit">
                                        <FaIcons.FaSave />Grabar
                                    </Button>
                                    <Button className="btn btn-danger" onClick={this.cancel} style={{ marginLeft: "18px" }} variant="primary">
                                        <ImIcons.ImCancelCircle />Cancelar
                                    </Button>
                                </Form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default EditSalaComponent;