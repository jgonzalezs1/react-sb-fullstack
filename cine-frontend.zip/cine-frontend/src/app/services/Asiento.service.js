import axios from 'axios'
import { environment } from '../../environment/.env.development'

class AsientoService {
    
    getAsiento(){
        return axios.get(`${environment.API_BASE_URL}asientos`)
    }

    getAsientoId(id){
        return axios.get(`${environment.API_BASE_URL}asientos/${id}`)
    }

    createAsiento(asiento){
        return axios.post(`${environment.API_BASE_URL}asientos`, asiento)
    }

    editAsiento(asiento){
        return axios.put(`${environment.API_BASE_URL}asientos`, asiento)
    }

    deleteAsiento(id){
        return axios.delete(`${environment.API_BASE_URL}asientos/${id}`)
    }

    patchAsiento(id){
        return axios.patch(`${environment.API_BASE_URL}asientos/inhabilite/${id}`)
    }
}

export default new AsientoService();