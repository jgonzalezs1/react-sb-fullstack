import axios from 'axios'
import { environment } from '../../environment/.env.development'

class CarteleraService {
    
    getCartelera(){
        return axios.get(`${environment.API_BASE_URL}carteleras`)
    }

    getCarteleraId(id){
        return axios.get(`${environment.API_BASE_URL}carteleras/${id}`)
    }

    getAsientosDisponiblesOcupadosSalaFecha(estado){
        return axios.get(`${environment.API_BASE_URL}carteleras/${estado}`)
    }

    createCartelera(cartelera){
        return axios.post(`${environment.API_BASE_URL}carteleras`, cartelera)
    }

    editCartelera(cartelera){
        return axios.put(`${environment.API_BASE_URL}carteleras`, cartelera)
    }

    deleteCartelera(id){
        return axios.delete(`${environment.API_BASE_URL}carteleras/${id}`)
    }
}

export default new CarteleraService();