import axios from 'axios'
import { environment } from '../../environment/.env.development'

class ReservaService {
    
    getReserva(){
        return axios.get(`${environment.API_BASE_URL}reservas`)
    }

    getReservaId(id){
        return axios.get(`${environment.API_BASE_URL}reservas/${id}`)
    }

    getGeneroFecha(filter){
        return axios.get(`${environment.API_BASE_URL}reservas/`, filter)
    }

    createReserva(reserva){
        return axios.post(`${environment.API_BASE_URL}reservas`, reserva)
    }

    editReserva(reserva){
        return axios.put(`${environment.API_BASE_URL}reservas`, reserva)
    }

    deleteReserva(id){
        return axios.delete(`${environment.API_BASE_URL}reservas/${id}`)
    }
}

export default new ReservaService();