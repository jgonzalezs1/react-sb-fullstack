import axios from 'axios'
import { environment } from '../../environment/.env.development'

class PeliculaService {
    
    getPelicula(){
        return axios.get(`${environment.API_BASE_URL}peliculas`)
    }

    getPeliculaId(id){
        return axios.get(`${environment.API_BASE_URL}peliculas/${id}`)
    }

    createPelicula(pelicula){
        return axios.post(`${environment.API_BASE_URL}peliculas`, pelicula)
    }

    editPelicula(pelicula){
        return axios.put(`${environment.API_BASE_URL}peliculas`, pelicula)
    }

    deletePelicula(id){
        return axios.delete(`${environment.API_BASE_URL}peliculas/${id}`)
    }
}

export default new PeliculaService();