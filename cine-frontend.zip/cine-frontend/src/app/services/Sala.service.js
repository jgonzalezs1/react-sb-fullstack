import axios from 'axios'
import { environment } from '../../environment/.env.development'

class SalaService {
    
    getSala(){
        return axios.get(`${environment.API_BASE_URL}salas`)
    }

    getSalaId(id){
        return axios.get(`${environment.API_BASE_URL}salas/${id}`)
    }

    createSala(sala){
        return axios.post(`${environment.API_BASE_URL}salas`, sala)
    }

    editSala(sala){
        return axios.put(`${environment.API_BASE_URL}salas`, sala)
    }

    deleteSala(id){
        return axios.delete(`${environment.API_BASE_URL}salas/${id}`)
    }
}

export default new SalaService();