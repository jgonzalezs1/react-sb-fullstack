import axios from 'axios'
import { environment } from '../../environment/.env.development'

class ClienteService {
    
    getCliente(){
        return axios.get(`${environment.API_BASE_URL}clientes`)
    }

    getClienteId(id){
        return axios.get(`${environment.API_BASE_URL}clientes/${id}`)
    }

    createCliente(cliente){
        return axios.post(`${environment.API_BASE_URL}clientes`, cliente)
    }

    editCliente(cliente){
        return axios.put(`${environment.API_BASE_URL}clientes`, cliente)
    }

    deleteCliente(id){
        return axios.delete(`${environment.API_BASE_URL}clientes/${id}`)
    }
}

export default new ClienteService();