import React from 'react';
import './App.css';
import Navbar from './app/components/Navbar';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { ToastContainer, Zoom } from 'react-toastify';
import ListClienteComponent from './app/pages/cliente/ListCliente.component';
import CreateClienteComponent from './app/pages/cliente/CreateCliente.component';
import EditClienteComponent from './app/pages/cliente/EditCliente.component';
import ListPeliculaComponent from './app/pages/pelicula/ListPelicula.component';
import CreatePeliculaComponent from './app/pages/pelicula/CreatePelicula.component';
import EditPeliculaComponent from './app/pages/pelicula/EditPelicula.component';
import ListSalaComponent from './app/pages/sala/ListSala.component';
import CreateSalaComponent from './app/pages/sala/CreateSala.component';
import EditSalaComponent from './app/pages/sala/EditSala.component';
import ListAsientoComponent from './app/pages/asiento/ListAsiento.component';
import CreateAsientoComponent from './app/pages/asiento/CreateAsiento.component';
import EditAsientoComponent from './app/pages/asiento/EditAsiento.component';
import PatchAsientoComponent from './app/pages/asiento/PatchAsiento.component';
import ListCarteleraComponent from './app/pages/cartelera/ListCartelera.component';
import CreateCarteleraComponent from './app/pages/cartelera/CreateCartelera.component';
import EditCarteleraComponent from './app/pages/cartelera/EditCartelera.component';
import ListReservaComponent from './app/pages/reserva/ListReserva.component';
import CreateReservaComponent from './app/pages/reserva/CreateReserva.component';
import EditReservaComponent from './app/pages/reserva/EditReserva.component';

function App() {
  return (
    <>
      <Router>
        <Switch>
          <Navbar />
        </Switch>
        <Switch>
          <Route path="/cliente" exact component={ListClienteComponent} />
          <Route path="/cliente/agregar-cliente" component={CreateClienteComponent} />
          <Route path="/cliente/editar-cliente/:id" component={EditClienteComponent} />
        </Switch>
        <Switch>
          <Route path="/pelicula" exact component={ListPeliculaComponent} />
          <Route path="/pelicula/agregar-pelicula" component={CreatePeliculaComponent} />
          <Route path="/pelicula/editar-pelicula/:id" component={EditPeliculaComponent} />
        </Switch>
        <Switch>
          <Route path="/sala" exact component={ListSalaComponent} />
          <Route path="/sala/agregar-sala" component={CreateSalaComponent} />
          <Route path="/sala/editar-sala/:id" component={EditSalaComponent} />
        </Switch>
        <Switch>
          <Route path="/asiento" exact component={ListAsientoComponent} />
          <Route path="/asiento/agregar-asiento" component={CreateAsientoComponent} />
          <Route path="/asiento/editar-asiento/:id" component={EditAsientoComponent} />
          <Route path="/asiento/inhabilitar-asiento/:id" component={PatchAsientoComponent} />
        </Switch>
        <Switch>
          <Route path="/cartelera" exact component={ListCarteleraComponent} />
          <Route path="/cartelera/agregar-cartelera" component={CreateCarteleraComponent} />
          <Route path="/cartelera/editar-cartelera/:id" component={EditCarteleraComponent} />
        </Switch>
        <Switch>
          <Route path="/reserva" exact component={ListReservaComponent} />
          <Route path="/reserva/agregar-reserva" component={CreateReservaComponent} />
          <Route path="/reserva/editar-reserva/:id" component={EditReservaComponent} />
        </Switch>
      </Router >
      <ToastContainer
        transition={Zoom}
        theme="colored"
        position="top-right"
        autoClose={1500}
        hideProgressBar
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
    </ >
  );
}

export default App;
