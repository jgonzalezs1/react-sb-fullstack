export const environment = {
    IS_PRODUCTION: true,
    API_BASE_URL: "http://localhost:8080/cine/api/v1/"
}