export const environment = {
    IS_PRODUCTION: false,
    API_BASE_URL: "http://localhost:8080/cine/api/v1/"
}